/*
============================================================
 HOSPITAL PATIENT QUEUE MANAGEMENT SYSTEM
 Developed using C++ with DSA Implementation
 Features: Queues, Priority Queues, Linked Lists, Sorting
============================================================
*/

#include <iostream>
#include <fstream>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <cstdlib>
#include <windows.h>  // For sleep function and colors
using namespace std;

// ====================== CONSTANTS ======================
const int MAX_REGULAR_QUEUE = 100;
const int MAX_EMERGENCY_QUEUE = 50;
const int MAX_PATIENTS = 200;
const string ADMIN_USER = "admin";
const string ADMIN_PASS = "admin123";

// ====================== COLOR CODES ======================
enum Color {
    BLACK = 0,
    BLUE = 1,
    GREEN = 2,
    CYAN = 3,
    RED = 4,
    MAGENTA = 5,
    YELLOW = 6,
    WHITE = 7,
    GRAY = 8,
    BRIGHT_BLUE = 9,
    BRIGHT_GREEN = 10,
    BRIGHT_CYAN = 11,
    BRIGHT_RED = 12,
    BRIGHT_MAGENTA = 13,
    BRIGHT_YELLOW = 14,
    BRIGHT_WHITE = 15
};

// ====================== UTILITY FUNCTIONS ======================
void setColor(int color) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
}

void sleep(int milliseconds) {
    Sleep(milliseconds);
}

void clearScreen() {
    system("cls");
}

void printHeader(const string& title) {
    setColor(BRIGHT_CYAN);
    cout << "\n╔════════════════════════════════════════════════════════════════╗\n";
    cout << "║";
    int spaces = (60 - title.length()) / 2;
    for(int i = 0; i < spaces; i++) cout << " ";
    cout << title;
    for(int i = 0; i < 60 - title.length() - spaces; i++) cout << " ";
    cout << "║\n";
    cout << "╚════════════════════════════════════════════════════════════════╝\n";
    setColor(WHITE);
}

void printSuccess(const string& message) {
    setColor(BRIGHT_GREEN);
    cout << "✓ " << message << endl;
    setColor(WHITE);
}

void printError(const string& message) {
    setColor(BRIGHT_RED);
    cout << "✗ " << message << endl;
    setColor(WHITE);
}

void printWarning(const string& message) {
    setColor(BRIGHT_YELLOW);
    cout << "⚠ " << message << endl;
    setColor(WHITE);
}

void printInfo(const string& message) {
    setColor(BRIGHT_CYAN);
    cout << "ℹ " << message << endl;
    setColor(WHITE);
}

void loadingAnimation(const string& message, int duration = 1000) {
    setColor(BRIGHT_YELLOW);
    cout << "\n" << message;
    for(int i = 0; i < 3; i++) {
        cout << ".";
        Sleep(duration/3);
    }
    cout << endl;
    setColor(WHITE);
}

// ====================== TIME FUNCTIONS ======================
time_t getCurrentTime() {
    return time(0);
}

string timeToString(time_t t) {
    char buffer[80];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", localtime(&t));
    return string(buffer);
}

// ====================== PATIENT STRUCTURE ======================
struct Patient {
    int id;
    char name[50];
    int age;
    char gender;
    int severity;        // 1-10 (1=normal, 10=critical)
    char problem[100];
    time_t arrivalTime;
    time_t consultationTime;
    int status;          // 0=waiting, 1=consulting, 2=discharged
    int queueType;       // 0=regular, 1=emergency
    
    // Constructor
    Patient() {
        id = 0;
        strcpy(name, "");
        age = 0;
        gender = 'M';
        severity = 1;
        strcpy(problem, "");
        arrivalTime = getCurrentTime();
        consultationTime = 0;
        status = 0;
        queueType = 0;
    }
};

// ====================== NODE FOR LINKED LIST ======================
struct Node {
    Patient patient;
    Node* next;
    
    Node(Patient p) {
        patient = p;
        next = NULL;
    }
};

// ====================== LINKED LIST CLASS ======================
class PatientList {
private:
    Node* head;
    int count;
    
public:
    PatientList() {
        head = NULL;
        count = 0;
    }
    
    // Add patient to linked list
    void addPatient(Patient p) {
        Node* newNode = new Node(p);
        
        if (head == NULL) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != NULL) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
        count++;
    }
    
    // Search patient by ID
    Patient* searchPatient(int id) {
        Node* temp = head;
        while (temp != NULL) {
            if (temp->patient.id == id) {
                return &(temp->patient);
            }
            temp = temp->next;
        }
        return NULL;
    }
    
    // Search patient by name
    void searchPatientByName(char name[]) {
        Node* temp = head;
        bool found = false;
        
        while (temp != NULL) {
            if (strstr(temp->patient.name, name) != NULL) {
                displayPatient(temp->patient);
                found = true;
            }
            temp = temp->next;
        }
        
        if (!found) {
            printError("No patient found with name containing: " + string(name));
        }
    }
    
    // Display all patients
    void displayAll() {
        if (head == NULL) {
            printInfo("No patients in records.");
            return;
        }
        
        Node* temp = head;
        int serial = 1;
        
        setColor(BRIGHT_MAGENTA);
        cout << "\n╔════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗\n";
        cout << "║                                          ALL PATIENT RECORDS                                             ║\n";
        cout << "╠════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╣\n";
        cout << "║ " << left << setw(5) << "Sr#" << setw(10) << "Patient ID" 
             << setw(25) << "Name" << setw(8) << "Age" 
             << setw(10) << "Gender" << setw(12) << "Severity"
             << setw(15) << "Status" << setw(25) << "Arrival Time" << "║\n";
        cout << "╠════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╣\n";
        
        while (temp != NULL) {
            cout << "║ " << left << setw(5) << serial++
                 << setw(10) << temp->patient.id
                 << setw(25) << temp->patient.name
                 << setw(8) << temp->patient.age
                 << setw(10) << temp->patient.gender
                 << setw(12) << temp->patient.severity;
            
            // Display status with color
            if (temp->patient.status == 0) {
                setColor(YELLOW);
                cout << setw(15) << "Waiting";
                setColor(BRIGHT_MAGENTA);
            }
            else if (temp->patient.status == 1) {
                setColor(BRIGHT_GREEN);
                cout << setw(15) << "Consulting";
                setColor(BRIGHT_MAGENTA);
            }
            else {
                setColor(GRAY);
                cout << setw(15) << "Discharged";
                setColor(BRIGHT_MAGENTA);
            }
            
            cout << setw(25) << timeToString(temp->patient.arrivalTime) << "║" << endl;
            
            temp = temp->next;
        }
        cout << "╚════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝\n";
        setColor(BRIGHT_CYAN);
        cout << "\nTotal Patients: " << count << endl;
        setColor(WHITE);
    }
    
    // Update patient status
    bool updateStatus(int id, int newStatus) {
        Patient* patient = searchPatient(id);
        if (patient != NULL) {
            patient->status = newStatus;
            if (newStatus == 1) { // Consulting
                patient->consultationTime = getCurrentTime();
            }
            return true;
        }
        return false;
    }
    
    // Get patient count
    int getCount() { return count; }
    
    // Display single patient details
    void displayPatient(const Patient& p) {
        setColor(BRIGHT_CYAN);
        cout << "\n╔════════════════════════════════════════════════════════════════╗\n";
        cout << "║                     PATIENT DETAILS                           ║\n";
        cout << "╠════════════════════════════════════════════════════════════════╣\n";
        setColor(WHITE);
        
        setColor(CYAN);
        cout << "  Patient ID:       " << p.id << endl;
        cout << "  Name:             " << p.name << endl;
        cout << "  Age:              " << p.age << endl;
        cout << "  Gender:           " << p.gender << endl;
        cout << "  Problem:          " << p.problem << endl;
        cout << "  Severity Level:   " << p.severity << "/10";
        
        // Color code severity
        if (p.severity >= 7) setColor(BRIGHT_RED);
        else if (p.severity >= 4) setColor(YELLOW);
        else setColor(GREEN);
        cout << " [" << (p.severity >= 7 ? "CRITICAL" : (p.severity >= 4 ? "MODERATE" : "MILD")) << "]\n";
        
        setColor(CYAN);
        cout << "  Queue Type:       ";
        if (p.queueType == 0) {
            setColor(BRIGHT_BLUE);
            cout << "Regular\n";
        } else {
            setColor(BRIGHT_RED);
            cout << "Emergency\n";
        }
        
        setColor(CYAN);
        cout << "  Status:           ";
        if (p.status == 0) {
            setColor(YELLOW);
            cout << "Waiting\n";
        } else if (p.status == 1) {
            setColor(BRIGHT_GREEN);
            cout << "Consulting\n";
        } else {
            setColor(GRAY);
            cout << "Discharged\n";
        }
        
        setColor(CYAN);
        cout << "  Arrival Time:     " << timeToString(p.arrivalTime) << endl;
        if (p.consultationTime > 0) {
            cout << "  Consultation Time: " << timeToString(p.consultationTime) << endl;
        }
        
        setColor(BRIGHT_CYAN);
        cout << "╚════════════════════════════════════════════════════════════════╝\n";
        setColor(WHITE);
    }
    
    // Save to file
    void saveToFile() {
        ofstream file("patients.dat", ios::binary);
        if (!file) {
            printError("Error saving patient data!");
            return;
        }
        
        Node* temp = head;
        while (temp != NULL) {
            file.write(reinterpret_cast<char*>(&temp->patient), sizeof(Patient));
            temp = temp->next;
        }
        
        file.close();
        printSuccess("Patient records saved successfully!");
    }
    
    // Load from file
    void loadFromFile() {
        ifstream file("patients.dat", ios::binary);
        if (!file) {
            printInfo("No previous patient data found. Starting fresh.");
            return;
        }
        
        loadingAnimation("Loading patient records");
        
        Patient p;
        while (file.read(reinterpret_cast<char*>(&p), sizeof(Patient))) {
            addPatient(p);
        }
        
        file.close();
        printSuccess("Loaded " + to_string(count) + " patient records");
    }
};

// ====================== REGULAR QUEUE (FIFO) ======================
class RegularQueue {
private:
    Patient queue[MAX_REGULAR_QUEUE];
    int front, rear;
    int count;
    
public:
    RegularQueue() {
        front = -1;
        rear = -1;
        count = 0;
    }
    
    // Check if queue is empty
    bool isEmpty() {
        return front == -1;
    }
    
    // Check if queue is full
    bool isFull() {
        return (rear + 1) % MAX_REGULAR_QUEUE == front;
    }
    
    // Enqueue patient
    bool enqueue(Patient p) {
        if (isFull()) {
            printError("Regular queue is full! Cannot add more patients.");
            return false;
        }
        
        if (isEmpty()) {
            front = rear = 0;
        } else {
            rear = (rear + 1) % MAX_REGULAR_QUEUE;
        }
        
        queue[rear] = p;
        count++;
        return true;
    }
    
    // Dequeue patient
    Patient dequeue() {
        Patient p;
        if (isEmpty()) {
            printError("Regular queue is empty!");
            return p;
        }
        
        p = queue[front];
        
        if (front == rear) {
            front = rear = -1;
        } else {
            front = (front + 1) % MAX_REGULAR_QUEUE;
        }
        
        count--;
        return p;
    }
    
    // Peek at front patient
    Patient peek() {
        if (isEmpty()) {
            Patient p;
            return p;
        }
        return queue[front];
    }
    
    // Display queue
    void display() {
        if (isEmpty()) {
            setColor(BRIGHT_BLUE);
            cout << "\n╔════════════════════════════════════════╗\n";
            cout << "║         REGULAR QUEUE: EMPTY          ║\n";
            cout << "╚════════════════════════════════════════╝\n";
            setColor(WHITE);
            return;
        }
        
        setColor(BRIGHT_BLUE);
        cout << "\n╔════════════════════════════════════════════════════════════════════════════════════════╗\n";
        cout << "║                     REGULAR QUEUE (" << setw(3) << count << " patients)                        ║\n";
        cout << "╠════════════════════════════════════════════════════════════════════════════════════════╣\n";
        cout << "║ " << left << setw(5) << "Pos" << setw(10) << "ID" 
             << setw(25) << "Name" << setw(10) << "Severity" 
             << setw(25) << "Arrival Time" << "║\n";
        cout << "╠════════════════════════════════════════════════════════════════════════════════════════╣\n";
        
        int i = front;
        int position = 1;
        
        do {
            cout << "║ " << left << setw(5) << position++
                 << setw(10) << queue[i].id
                 << setw(25) << queue[i].name;
            
            // Color code severity
            if (queue[i].severity >= 7) setColor(BRIGHT_RED);
            else if (queue[i].severity >= 4) setColor(YELLOW);
            else setColor(GREEN);
            cout << setw(10) << queue[i].severity;
            setColor(BRIGHT_BLUE);
            
            cout << setw(25) << timeToString(queue[i].arrivalTime) << "║" << endl;
            
            i = (i + 1) % MAX_REGULAR_QUEUE;
        } while (i != (rear + 1) % MAX_REGULAR_QUEUE);
        
        cout << "╚════════════════════════════════════════════════════════════════════════════════════════╝\n";
        setColor(WHITE);
    }
    
    // Get queue count
    int getCount() { return count; }
};

// ====================== EMERGENCY QUEUE (PRIORITY) ======================
class EmergencyQueue {
private:
    Patient heap[MAX_EMERGENCY_QUEUE];
    int heapSize;
    
    // Heapify functions
    void heapifyUp(int index) {
        while (index > 0 && heap[parent(index)].severity < heap[index].severity) {
            swap(heap[index], heap[parent(index)]);
            index = parent(index);
        }
    }
    
    void heapifyDown(int index) {
        int maxIndex = index;
        int left = leftChild(index);
        int right = rightChild(index);
        
        if (left < heapSize && heap[left].severity > heap[maxIndex].severity) {
            maxIndex = left;
        }
        
        if (right < heapSize && heap[right].severity > heap[maxIndex].severity) {
            maxIndex = right;
        }
        
        if (index != maxIndex) {
            swap(heap[index], heap[maxIndex]);
            heapifyDown(maxIndex);
        }
    }
    
    int parent(int i) { return (i - 1) / 2; }
    int leftChild(int i) { return 2 * i + 1; }
    int rightChild(int i) { return 2 * i + 2; }
    
public:
    EmergencyQueue() {
        heapSize = 0;
    }
    
    // Check if empty
    bool isEmpty() {
        return heapSize == 0;
    }
    
    // Check if full
    bool isFull() {
        return heapSize >= MAX_EMERGENCY_QUEUE;
    }
    
    // Enqueue patient (insert into max-heap)
    bool enqueue(Patient p) {
        if (isFull()) {
            printError("Emergency queue is full! Cannot add more patients.");
            return false;
        }
        
        heap[heapSize] = p;
        heapifyUp(heapSize);
        heapSize++;
        return true;
    }
    
    // Dequeue patient (extract max severity)
    Patient dequeue() {
        Patient p;
        if (isEmpty()) {
            printError("Emergency queue is empty!");
            return p;
        }
        
        p = heap[0];
        heap[0] = heap[heapSize - 1];
        heapSize--;
        heapifyDown(0);
        
        return p;
    }
    
    // Peek at highest priority patient
    Patient peek() {
        if (isEmpty()) {
            Patient p;
            return p;
        }
        return heap[0];
    }
    
    // Display emergency queue
    void display() {
        if (isEmpty()) {
            setColor(BRIGHT_RED);
            cout << "\n╔════════════════════════════════════════╗\n";
            cout << "║       EMERGENCY QUEUE: EMPTY         ║\n";
            cout << "╚════════════════════════════════════════╝\n";
            setColor(WHITE);
            return;
        }
        
        // Create temporary array for sorting display
        Patient temp[MAX_EMERGENCY_QUEUE];
        for (int i = 0; i < heapSize; i++) {
            temp[i] = heap[i];
        }
        
        // Sort by severity for display (bubble sort)
        for (int i = 0; i < heapSize - 1; i++) {
            for (int j = 0; j < heapSize - i - 1; j++) {
                if (temp[j].severity < temp[j + 1].severity) {
                    swap(temp[j], temp[j + 1]);
                }
            }
        }
        
        setColor(BRIGHT_RED);
        cout << "\n╔════════════════════════════════════════════════════════════════════════════════════════╗\n";
        cout << "║                   EMERGENCY QUEUE (" << setw(3) << heapSize << " patients)                        ║\n";
        cout << "╠════════════════════════════════════════════════════════════════════════════════════════╣\n";
        cout << "║ " << left << setw(5) << "Pos" << setw(10) << "ID" 
             << setw(25) << "Name" << setw(10) << "Severity" 
             << setw(25) << "Arrival Time" << "║\n";
        cout << "╠════════════════════════════════════════════════════════════════════════════════════════╣\n";
        
        for (int i = 0; i < heapSize; i++) {
            cout << "║ " << left << setw(5) << i + 1
                 << setw(10) << temp[i].id
                 << setw(25) << temp[i].name;
            
            // Color code based on severity
            if (temp[i].severity >= 9) setColor(BRIGHT_RED);
            else if (temp[i].severity >= 7) setColor(YELLOW);
            else setColor(WHITE);
            
            cout << setw(10) << temp[i].severity;
            setColor(BRIGHT_RED);
            cout << setw(25) << timeToString(temp[i].arrivalTime) << "║" << endl;
        }
        
        cout << "╚════════════════════════════════════════════════════════════════════════════════════════╝\n";
        setColor(WHITE);
    }
    
    // Get queue count
    int getCount() { return heapSize; }
};

// ====================== HOSPITAL MANAGEMENT SYSTEM ======================
class HospitalSystem {
private:
    RegularQueue regularQueue;
    EmergencyQueue emergencyQueue;
    PatientList patientList;
    int nextPatientID;
    
public:
    HospitalSystem() {
        nextPatientID = 1001;
    }
    
    // Initialize system
    void initialize() {
        clearScreen();
        printHeader("HOSPITAL PATIENT QUEUE MANAGEMENT SYSTEM");
        
        setColor(BRIGHT_YELLOW);
        cout << "\n⚕️  DEVELOPED USING C++ WITH DSA IMPLEMENTATION ⚕️\n";
        cout << "   Advanced Queue Management with Priority Handling\n";
        cout << "   ════════════════════════════════════════════════\n";
        setColor(WHITE);
        
        loadingAnimation("Initializing system");
        
        // Load existing data
        patientList.loadFromFile();
        
        // Find maximum ID for nextPatientID
        nextPatientID = 1001 + patientList.getCount();
        
        printSuccess("System initialized successfully!");
        cout << "Next Patient ID: ";
        setColor(BRIGHT_GREEN);
        cout << nextPatientID << endl;
        setColor(WHITE);
        
        sleep(1500);
    }
    
    // Register new patient
    void registerPatient() {
        clearScreen();
        printHeader("PATIENT REGISTRATION");
        
        Patient p;
        p.id = nextPatientID++;
        
        setColor(BRIGHT_CYAN);
        cout << "\n  Patient ID: ";
        setColor(BRIGHT_GREEN);
        cout << p.id << endl;
        setColor(WHITE);
        
        cin.ignore();
        
        setColor(CYAN);
        cout << "\n  ──────────────────────────────────────\n";
        cout << "  Please enter patient details:\n";
        cout << "  ──────────────────────────────────────\n";
        setColor(WHITE);
        
        cout << "  Full Name: ";
        setColor(BRIGHT_WHITE);
        cin.getline(p.name, 50);
        setColor(WHITE);
        
        cout << "  Age: ";
        setColor(BRIGHT_WHITE);
        cin >> p.age;
        setColor(WHITE);
        
        cout << "  Gender (M/F): ";
        setColor(BRIGHT_WHITE);
        cin >> p.gender;
        setColor(WHITE);
        
        cout << "  Problem Description: ";
        cin.ignore();
        setColor(BRIGHT_WHITE);
        cin.getline(p.problem, 100);
        setColor(WHITE);
        
        cout << "  Severity Level (1-10, 1=Normal, 10=Critical): ";
        setColor(BRIGHT_WHITE);
        cin >> p.severity;
        setColor(WHITE);
        
        // Validate severity
        if (p.severity < 1) p.severity = 1;
        if (p.severity > 10) p.severity = 10;
        
        loadingAnimation("Processing registration");
        
        // Determine queue type based on severity
        if (p.severity >= 7) {
            p.queueType = 1; // Emergency
            if (emergencyQueue.enqueue(p)) {
                setColor(BRIGHT_RED);
                cout << "\n  ⚠ URGENT: Patient added to EMERGENCY QUEUE (Priority)\n";
                setColor(WHITE);
            }
        } else {
            p.queueType = 0; // Regular
            if (regularQueue.enqueue(p)) {
                setColor(BRIGHT_BLUE);
                cout << "\n  Patient added to REGULAR QUEUE\n";
                setColor(WHITE);
            }
        }
        
        // Add to patient list
        patientList.addPatient(p);
        
        printSuccess("Registration Successful! Patient ID: " + to_string(p.id));
        
        sleep(2000);
    }
    
    // Add emergency patient directly
    void addEmergencyPatient() {
        clearScreen();
        printHeader("EMERGENCY PATIENT REGISTRATION");
        
        Patient p;
        p.id = nextPatientID++;
        p.queueType = 1; // Emergency
        
        setColor(BRIGHT_RED);
        cout << "\n  ⚠⚠⚠ EMERGENCY REGISTRATION ⚠⚠⚠\n";
        cout << "  Patient ID: " << p.id << endl;
        setColor(WHITE);
        
        cin.ignore();
        
        cout << "\n  Full Name: ";
        setColor(BRIGHT_WHITE);
        cin.getline(p.name, 50);
        setColor(WHITE);
        
        cout << "  Age: ";
        setColor(BRIGHT_WHITE);
        cin >> p.age;
        setColor(WHITE);
        
        cout << "  Gender (M/F): ";
        setColor(BRIGHT_WHITE);
        cin >> p.gender;
        setColor(WHITE);
        
        cout << "  Problem Description: ";
        cin.ignore();
        setColor(BRIGHT_WHITE);
        cin.getline(p.problem, 100);
        setColor(WHITE);
        
        cout << "  Severity Level (7-10): ";
        setColor(BRIGHT_WHITE);
        cin >> p.severity;
        setColor(WHITE);
        
        // Force high severity for emergency
        if (p.severity < 7) p.severity = 7;
        if (p.severity > 10) p.severity = 10;
        
        loadingAnimation("Processing emergency registration", 800);
        
        if (emergencyQueue.enqueue(p)) {
            setColor(BRIGHT_RED);
            cout << "\n  ⚠⚠⚠ EMERGENCY PATIENT ADDED WITH HIGHEST PRIORITY! ⚠⚠⚠\n";
            setColor(WHITE);
            patientList.addPatient(p);
        }
        
        sleep(2000);
    }
    
    // Consult next patient
    void consultNextPatient() {
        clearScreen();
        printHeader("CONSULT NEXT PATIENT");
        
        // First check emergency queue
        if (!emergencyQueue.isEmpty()) {
            Patient p = emergencyQueue.dequeue();
            patientList.updateStatus(p.id, 1);
            
            setColor(BRIGHT_RED);
            cout << "\n  ⚕️ CONSULTING EMERGENCY PATIENT:\n";
            setColor(WHITE);
            
            patientList.displayPatient(p);
            
            setColor(BRIGHT_YELLOW);
            cout << "\n  Proceeding with consultation...\n";
            setColor(WHITE);
        }
        // Then check regular queue
        else if (!regularQueue.isEmpty()) {
            Patient p = regularQueue.dequeue();
            patientList.updateStatus(p.id, 1);
            
            setColor(BRIGHT_BLUE);
            cout << "\n  ⚕️ CONSULTING REGULAR PATIENT:\n";
            setColor(WHITE);
            
            patientList.displayPatient(p);
            
            setColor(BRIGHT_YELLOW);
            cout << "\n  Proceeding with consultation...\n";
            setColor(WHITE);
        }
        else {
            printError("No patients waiting for consultation.");
        }
        
        sleep(3000);
    }
    
    // View current queues
    void viewQueues() {
        clearScreen();
        printHeader("CURRENT QUEUE STATUS");
        
        emergencyQueue.display();
        cout << endl;
        regularQueue.display();
        
        setColor(BRIGHT_MAGENTA);
        cout << "\n╔════════════════════════════════════════════════════════════════╗\n";
        cout << "║                     QUEUE STATISTICS                          ║\n";
        cout << "╠════════════════════════════════════════════════════════════════╣\n";
        
        cout << "║ ";
        setColor(BRIGHT_RED);
        cout << "Emergency Patients: " << setw(3) << emergencyQueue.getCount();
        setColor(BRIGHT_MAGENTA);
        cout << "                          ║\n";
        
        cout << "║ ";
        setColor(BRIGHT_BLUE);
        cout << "Regular Patients:   " << setw(3) << regularQueue.getCount();
        setColor(BRIGHT_MAGENTA);
        cout << "                          ║\n";
        
        cout << "║ ";
        setColor(BRIGHT_YELLOW);
        cout << "Total Waiting:      " << setw(3) << emergencyQueue.getCount() + regularQueue.getCount();
        setColor(BRIGHT_MAGENTA);
        cout << "                          ║\n";
        
        cout << "╚════════════════════════════════════════════════════════════════╝\n";
        setColor(WHITE);
        
        sleep(3000);
    }
    
    // Search patient
    void searchPatient() {
        clearScreen();
        printHeader("SEARCH PATIENT");
        
        int choice;
        setColor(CYAN);
        cout << "\n  [1] Search by Patient ID\n";
        cout << "  [2] Search by Name\n";
        cout << "\n  Enter choice: ";
        setColor(BRIGHT_WHITE);
        cin >> choice;
        setColor(WHITE);
        
        if (choice == 1) {
            int id;
            cout << "\n  Enter Patient ID: ";
            setColor(BRIGHT_WHITE);
            cin >> id;
            setColor(WHITE);
            
            Patient* p = patientList.searchPatient(id);
            if (p != NULL) {
                patientList.displayPatient(*p);
            } else {
                printError("Patient not found!");
            }
        }
        else if (choice == 2) {
            char name[50];
            cout << "\n  Enter Patient Name: ";
            cin.ignore();
            setColor(BRIGHT_WHITE);
            cin.getline(name, 50);
            setColor(WHITE);
            
            loadingAnimation("Searching patient records");
            patientList.searchPatientByName(name);
        }
        else {
            printError("Invalid choice!");
        }
        
        sleep(3000);
    }
    
    // Discharge patient
    void dischargePatient() {
        clearScreen();
        printHeader("DISCHARGE PATIENT");
        
        int id;
        cout << "\n  Enter Patient ID to discharge: ";
        setColor(BRIGHT_WHITE);
        cin >> id;
        setColor(WHITE);
        
        loadingAnimation("Processing discharge");
        
        if (patientList.updateStatus(id, 2)) {
            printSuccess("Patient discharged successfully!");
        } else {
            printError("Patient not found!");
        }
        
        sleep(2000);
    }
    
    // Generate reports
    void generateReports() {
        clearScreen();
        printHeader("SYSTEM REPORTS");
        
        setColor(BRIGHT_CYAN);
        cout << "\n╔════════════════════════════════════════════════════════════════╗\n";
        cout << "║                 HOSPITAL STATISTICS                          ║\n";
        cout << "╠════════════════════════════════════════════════════════════════╣\n";
        cout << "║                                                                ║\n";
        
        cout << "║  Total Patients Registered: ";
        setColor(BRIGHT_GREEN);
        cout << setw(5) << patientList.getCount();
        setColor(BRIGHT_CYAN);
        cout << "                        ║\n";
        
        cout << "║  Patients in Emergency Queue: ";
        setColor(BRIGHT_RED);
        cout << setw(3) << emergencyQueue.getCount();
        setColor(BRIGHT_CYAN);
        cout << "                           ║\n";
        
        cout << "║  Patients in Regular Queue: ";
        setColor(BRIGHT_BLUE);
        cout << setw(3) << regularQueue.getCount();
        setColor(BRIGHT_CYAN);
        cout << "                            ║\n";
        
        cout << "║  Total Waiting Patients: ";
        setColor(BRIGHT_YELLOW);
        cout << setw(3) << emergencyQueue.getCount() + regularQueue.getCount();
        setColor(BRIGHT_CYAN);
        cout << "                             ║\n";
        cout << "║                                                                ║\n";
        
        // Display next patient from each queue
        cout << "║  Next Emergency Patient: ";
        if (!emergencyQueue.isEmpty()) {
            Patient p = emergencyQueue.peek();
            setColor(BRIGHT_RED);
            cout << p.name << " (Severity: " << p.severity << ")";
            setColor(BRIGHT_CYAN);
            cout << "          ║\n";
        } else {
            setColor(GRAY);
            cout << "None";
            setColor(BRIGHT_CYAN);
            cout << "                                     ║\n";
        }
        
        cout << "║  Next Regular Patient: ";
        if (!regularQueue.isEmpty()) {
            Patient p = regularQueue.peek();
            setColor(BRIGHT_BLUE);
            cout << p.name << " (Arrived: " << timeToString(p.arrivalTime) << ")";
            setColor(BRIGHT_CYAN);
            int spaces = 60 - (24 + strlen(p.name) + 26);
            for(int i = 0; i < spaces; i++) cout << " ";
            cout << "║\n";
        } else {
            setColor(GRAY);
            cout << "None";
            setColor(BRIGHT_CYAN);
            cout << "                                      ║\n";
        }
        
        cout << "║                                                                ║\n";
        cout << "╚════════════════════════════════════════════════════════════════╝\n";
        setColor(WHITE);
        
        sleep(4000);
    }
    
    // View all patients
    void viewAllPatients() {
        clearScreen();
        printHeader("ALL PATIENT RECORDS");
        patientList.displayAll();
        sleep(4000);
    }
    
    // Save all data
    void saveAllData() {
        clearScreen();
        printHeader("SAVE DATA");
        
        loadingAnimation("Saving all patient data to file", 1500);
        patientList.saveToFile();
        
        sleep(2000);
    }
    
    // Admin login
    bool adminLogin() {
        clearScreen();
        printHeader("ADMINISTRATOR LOGIN");
        
        string username, password;
        int attempts = 3;
        
        while (attempts > 0) {
            setColor(CYAN);
            cout << "\n  Username: ";
            setColor(BRIGHT_WHITE);
            cin >> username;
            
            setColor(CYAN);
            cout << "  Password: ";
            setColor(BRIGHT_WHITE);
            cin >> password;
            setColor(WHITE);
            
            if (username == ADMIN_USER && password == ADMIN_PASS) {
                loadingAnimation("Verifying credentials", 1000);
                printSuccess("Login successful!");
                sleep(1500);
                return true;
            } else {
                attempts--;
                if (attempts > 0) {
                    setColor(BRIGHT_RED);
                    cout << "\n  ✗ Invalid credentials. Attempts left: " << attempts << endl;
                    setColor(WHITE);
                    sleep(1000);
                }
            }
        }
        
        printError("Maximum login attempts reached. Access denied!");
        sleep(2000);
        return false;
    }
    
    // Main menu
    void mainMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("HOSPITAL QUEUE MANAGEMENT SYSTEM");
            
            setColor(BRIGHT_YELLOW);
            cout << "\n  ╔════════════════════════════════════════════════════════════════╗\n";
            cout << "  ║                      MAIN MENU                               ║\n";
            cout << "  ╠════════════════════════════════════════════════════════════════╣\n";
            setColor(WHITE);
            
            setColor(CYAN);
            cout << "  ║  [1]  Register New Patient                                  ║\n";
            cout << "  ║  [2]  View Current Queues                                   ║\n";
            cout << "  ║  [3]  Add Emergency Patient                                 ║\n";
            cout << "  ║  [4]  Consult Next Patient                                  ║\n";
            cout << "  ║  [5]  Search Patient                                        ║\n";
            cout << "  ║  [6]  Generate Reports                                      ║\n";
            cout << "  ║  [7]  View All Patients                                     ║\n";
            cout << "  ║  [8]  Discharge Patient                                     ║\n";
            cout << "  ║  [9]  Save Data                                             ║\n";
            cout << "  ║  [10] Exit System                                           ║\n";
            setColor(BRIGHT_YELLOW);
            cout << "  ╠════════════════════════════════════════════════════════════════╣\n";
            cout << "  ║  Select option [1-10]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE);
            
            switch (choice) {
                case 1: registerPatient(); break;
                case 2: viewQueues(); break;
                case 3: addEmergencyPatient(); break;
                case 4: consultNextPatient(); break;
                case 5: searchPatient(); break;
                case 6: generateReports(); break;
                case 7: viewAllPatients(); break;
                case 8: dischargePatient(); break;
                case 9: saveAllData(); break;
                case 10: 
                    clearScreen();
                    printHeader("EXIT SYSTEM");
                    cout << "\n";
                    break;
                default:
                    printError("Invalid choice! Please try again.");
                    sleep(2000);
            }
            
        } while (choice != 10);
    }
    
    // Run system
    void run() {
        initialize();
        
        if (!adminLogin()) {
            return;
        }
        
        mainMenu();
        
        // Ask to save before exit
        clearScreen();
        printHeader("EXIT SYSTEM");
        
        char save;
        setColor(BRIGHT_YELLOW);
        cout << "\n  Save data before exiting? (y/n): ";
        setColor(BRIGHT_WHITE);
        cin >> save;
        setColor(WHITE);
        
        if (save == 'y' || save == 'Y') {
            saveAllData();
        }
        
        clearScreen();
        setColor(BRIGHT_CYAN);
        cout << "\n╔════════════════════════════════════════════════════════════════╗\n";
        cout << "║                                                                ║\n";
        cout << "║                THANK YOU FOR USING                            ║\n";
        cout << "║          HOSPITAL QUEUE MANAGEMENT SYSTEM                     ║\n";
        cout << "║                                                                ║\n";
        cout << "║                     Goodbye!                                   ║\n";
        cout << "║                                                                ║\n";
        cout << "╚════════════════════════════════════════════════════════════════╝\n";
        setColor(WHITE);
        
        sleep(2000);
    }
};

// ====================== MAIN FUNCTION ======================
int main() {
    HospitalSystem hospital;
    hospital.run();
    return 0;
}