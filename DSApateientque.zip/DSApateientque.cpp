/*
============================================================
 HOSPITAL PATIENT QUEUE MANAGEMENT SYSTEM
 Developed using C++ with DSA Implementation
 Features: Queues, Priority Queues, Linked Lists, Sorting
============================================================
*/

#include <iostream>
#include <fstream>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <cstdlib>
using namespace std;

// ====================== CONSTANTS ======================
const int MAX_REGULAR_QUEUE = 100;
const int MAX_EMERGENCY_QUEUE = 50;
const int MAX_PATIENTS = 200;
const string ADMIN_USER = "admin";
const string ADMIN_PASS = "admin123";

// ====================== TIME FUNCTIONS ======================
time_t getCurrentTime() {
    return time(0);
}

string timeToString(time_t t) {
    char buffer[80];
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", localtime(&t));
    return string(buffer);
}

// ====================== PATIENT STRUCTURE ======================
struct Patient {
    int id;
    char name[50];
    int age;
    char gender;
    int severity;        // 1-10 (1=normal, 10=critical)
    char problem[100];
    time_t arrivalTime;
    time_t consultationTime;
    int status;          // 0=waiting, 1=consulting, 2=discharged
    int queueType;       // 0=regular, 1=emergency
    
    // Constructor
    Patient() {
        id = 0;
        strcpy(name, "");
        age = 0;
        gender = 'M';
        severity = 1;
        strcpy(problem, "");
        arrivalTime = getCurrentTime();
        consultationTime = 0;
        status = 0;
        queueType = 0;
    }
};

// ====================== NODE FOR LINKED LIST ======================
struct Node {
    Patient patient;
    Node* next;
    
    Node(Patient p) {
        patient = p;
        next = NULL;
    }
};

// ====================== LINKED LIST CLASS ======================
class PatientList {
private:
    Node* head;
    int count;
    
public:
    PatientList() {
        head = NULL;
        count = 0;
    }
    
    // Add patient to linked list
    void addPatient(Patient p) {
        Node* newNode = new Node(p);
        
        if (head == NULL) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != NULL) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
        count++;
    }
    
    // Search patient by ID
    Patient* searchPatient(int id) {
        Node* temp = head;
        while (temp != NULL) {
            if (temp->patient.id == id) {
                return &(temp->patient);
            }
            temp = temp->next;
        }
        return NULL;
    }
    
    // Search patient by name
    void searchPatientByName(char name[]) {
        Node* temp = head;
        bool found = false;
        
        while (temp != NULL) {
            if (strstr(temp->patient.name, name) != NULL) {
                displayPatient(temp->patient);
                found = true;
            }
            temp = temp->next;
        }
        
        if (!found) {
            cout << "\n? No patient found with name containing: " << name << endl;
        }
    }
    
    // Display all patients
    void displayAll() {
        if (head == NULL) {
            cout << "\nNo patients in records.\n";
            return;
        }
        
        Node* temp = head;
        int serial = 1;
        
        cout << "\n----------------------------------------------------------------\n";
        cout << "                        ALL PATIENT RECORDS\n";
        cout << "----------------------------------------------------------------\n";
        cout << left << setw(5) << "Sr#" << setw(10) << "Patient ID" 
             << setw(25) << "Name" << setw(8) << "Age" 
             << setw(10) << "Gender" << setw(12) << "Severity"
             << setw(15) << "Status" << setw(20) << "Arrival Time" << endl;
        cout << string(115, '-') << endl;
        
        while (temp != NULL) {
            cout << left << setw(5) << serial++
                 << setw(10) << temp->patient.id
                 << setw(25) << temp->patient.name
                 << setw(8) << temp->patient.age
                 << setw(10) << temp->patient.gender
                 << setw(12) << temp->patient.severity;
            
            // Display status
            if (temp->patient.status == 0) cout << setw(15) << "Waiting";
            else if (temp->patient.status == 1) cout << setw(15) << "Consulting";
            else cout << setw(15) << "Discharged";
            
            cout << setw(20) << timeToString(temp->patient.arrivalTime) << endl;
            
            temp = temp->next;
        }
        cout << "----------------------------------------------------------------\n";
        cout << "Total Patients: " << count << endl;
    }
    
    // Update patient status
    bool updateStatus(int id, int newStatus) {
        Patient* patient = searchPatient(id);
        if (patient != NULL) {
            patient->status = newStatus;
            if (newStatus == 1) { // Consulting
                patient->consultationTime = getCurrentTime();
            }
            return true;
        }
        return false;
    }
    
    // Get patient count
    int getCount() { return count; }
    
    // Display single patient details
    void displayPatient(const Patient& p) {
        cout << "\n----------------------------------------\n";
        cout << "         PATIENT DETAILS\n";
        cout << "----------------------------------------\n";
        cout << left << setw(20) << "Patient ID:" << p.id << endl;
        cout << setw(20) << "Name:" << p.name << endl;
        cout << setw(20) << "Age:" << p.age << endl;
        cout << setw(20) << "Gender:" << p.gender << endl;
        cout << setw(20) << "Problem:" << p.problem << endl;
        cout << setw(20) << "Severity Level:" << p.severity << "/10" << endl;
        cout << setw(20) << "Queue Type:" 
             << (p.queueType == 0 ? "Regular" : "Emergency") << endl;
        cout << setw(20) << "Status:";
        if (p.status == 0) cout << "Waiting";
        else if (p.status == 1) cout << "Consulting";
        else cout << "Discharged";
        cout << endl;
        cout << setw(20) << "Arrival Time:" << timeToString(p.arrivalTime) << endl;
        if (p.consultationTime > 0) {
            cout << setw(20) << "Consultation Time:" << timeToString(p.consultationTime) << endl;
        }
        cout << "----------------------------------------\n";
    }
    
    // Save to file
    void saveToFile() {
        ofstream file("patients.dat", ios::binary);
        if (!file) {
            cout << "Error saving patient data!\n";
            return;
        }
        
        Node* temp = head;
        while (temp != NULL) {
            file.write(reinterpret_cast<char*>(&temp->patient), sizeof(Patient));
            temp = temp->next;
        }
        
        file.close();
        cout << "\n? Patient records saved successfully!\n";
    }
    
    // Load from file
    void loadFromFile() {
        ifstream file("patients.dat", ios::binary);
        if (!file) {
            cout << "No previous patient data found. Starting fresh.\n";
            return;
        }
        
        Patient p;
        while (file.read(reinterpret_cast<char*>(&p), sizeof(Patient))) {
            addPatient(p);
        }
        
        file.close();
        cout << "? Loaded " << count << " patient records.\n";
    }
};

// ====================== REGULAR QUEUE (FIFO) ======================
class RegularQueue {
private:
    Patient queue[MAX_REGULAR_QUEUE];
    int front, rear;
    int count;
    
public:
    RegularQueue() {
        front = -1;
        rear = -1;
        count = 0;
    }
    
    // Check if queue is empty
    bool isEmpty() {
        return front == -1;
    }
    
    // Check if queue is full
    bool isFull() {
        return (rear + 1) % MAX_REGULAR_QUEUE == front;
    }
    
    // Enqueue patient
    bool enqueue(Patient p) {
        if (isFull()) {
            cout << "\n? Regular queue is full! Cannot add more patients.\n";
            return false;
        }
        
        if (isEmpty()) {
            front = rear = 0;
        } else {
            rear = (rear + 1) % MAX_REGULAR_QUEUE;
        }
        
        queue[rear] = p;
        count++;
        return true;
    }
    
    // Dequeue patient
    Patient dequeue() {
        Patient p;
        if (isEmpty()) {
            cout << "\n? Regular queue is empty!\n";
            return p;
        }
        
        p = queue[front];
        
        if (front == rear) {
            front = rear = -1;
        } else {
            front = (front + 1) % MAX_REGULAR_QUEUE;
        }
        
        count--;
        return p;
    }
    
    // Peek at front patient
    Patient peek() {
        if (isEmpty()) {
            Patient p;
            return p;
        }
        return queue[front];
    }
    
    // Display queue
    void display() {
        if (isEmpty()) {
            cout << "\nRegular Queue: EMPTY\n";
            return;
        }
        
        cout << "\n----------------------------------------\n";
        cout << "          REGULAR QUEUE (" << count << " patients)\n";
        cout << "----------------------------------------\n";
        
        int i = front;
        int position = 1;
        
        cout << left << setw(5) << "Pos" << setw(10) << "ID" 
             << setw(25) << "Name" << setw(10) << "Severity" 
             << setw(25) << "Arrival Time" << endl;
        cout << string(75, '-') << endl;
        
        do {
            cout << left << setw(5) << position++
                 << setw(10) << queue[i].id
                 << setw(25) << queue[i].name
                 << setw(10) << queue[i].severity
                 << setw(25) << timeToString(queue[i].arrivalTime) << endl;
            
            i = (i + 1) % MAX_REGULAR_QUEUE;
        } while (i != (rear + 1) % MAX_REGULAR_QUEUE);
        
        cout << "----------------------------------------\n";
    }
    
    // Get queue count
    int getCount() { return count; }
};

// ====================== EMERGENCY QUEUE (PRIORITY) ======================
class EmergencyQueue {
private:
    Patient heap[MAX_EMERGENCY_QUEUE];
    int heapSize;
    
    // Heapify functions
    void heapifyUp(int index) {
        while (index > 0 && heap[parent(index)].severity < heap[index].severity) {
            swap(heap[index], heap[parent(index)]);
            index = parent(index);
        }
    }
    
    void heapifyDown(int index) {
        int maxIndex = index;
        int left = leftChild(index);
        int right = rightChild(index);
        
        if (left < heapSize && heap[left].severity > heap[maxIndex].severity) {
            maxIndex = left;
        }
        
        if (right < heapSize && heap[right].severity > heap[maxIndex].severity) {
            maxIndex = right;
        }
        
        if (index != maxIndex) {
            swap(heap[index], heap[maxIndex]);
            heapifyDown(maxIndex);
        }
    }
    
    int parent(int i) { return (i - 1) / 2; }
    int leftChild(int i) { return 2 * i + 1; }
    int rightChild(int i) { return 2 * i + 2; }
    
public:
    EmergencyQueue() {
        heapSize = 0;
    }
    
    // Check if empty
    bool isEmpty() {
        return heapSize == 0;
    }
    
    // Check if full
    bool isFull() {
        return heapSize >= MAX_EMERGENCY_QUEUE;
    }
    
    // Enqueue patient (insert into max-heap)
    bool enqueue(Patient p) {
        if (isFull()) {
            cout << "\n? Emergency queue is full! Cannot add more patients.\n";
            return false;
        }
        
        heap[heapSize] = p;
        heapifyUp(heapSize);
        heapSize++;
        return true;
    }
    
    // Dequeue patient (extract max severity)
    Patient dequeue() {
        Patient p;
        if (isEmpty()) {
            cout << "\n? Emergency queue is empty!\n";
            return p;
        }
        
        p = heap[0];
        heap[0] = heap[heapSize - 1];
        heapSize--;
        heapifyDown(0);
        
        return p;
    }
    
    // Peek at highest priority patient
    Patient peek() {
        if (isEmpty()) {
            Patient p;
            return p;
        }
        return heap[0];
    }
    
    // Display emergency queue
    void display() {
        if (isEmpty()) {
            cout << "\nEmergency Queue: EMPTY\n";
            return;
        }
        
        // Create temporary array for sorting display
        Patient temp[MAX_EMERGENCY_QUEUE];
        for (int i = 0; i < heapSize; i++) {
            temp[i] = heap[i];
        }
        
        // Sort by severity for display (bubble sort)
        for (int i = 0; i < heapSize - 1; i++) {
            for (int j = 0; j < heapSize - i - 1; j++) {
                if (temp[j].severity < temp[j + 1].severity) {
                    swap(temp[j], temp[j + 1]);
                }
            }
        }
        
        cout << "\n----------------------------------------\n";
        cout << "        EMERGENCY QUEUE (" << heapSize << " patients)\n";
        cout << "----------------------------------------\n";
        cout << left << setw(5) << "Pos" << setw(10) << "ID" 
             << setw(25) << "Name" << setw(10) << "Severity" 
             << setw(25) << "Arrival Time" << endl;
        cout << string(75, '-') << endl;
        
        for (int i = 0; i < heapSize; i++) {
            cout << left << setw(5) << i + 1
                 << setw(10) << temp[i].id
                 << setw(25) << temp[i].name
                 << setw(10) << temp[i].severity
                 << setw(25) << timeToString(temp[i].arrivalTime) << endl;
        }
        
        cout << "----------------------------------------\n";
    }
    
    // Get queue count
    int getCount() { return heapSize; }
};

// ====================== HOSPITAL MANAGEMENT SYSTEM ======================
class HospitalSystem {
private:
    RegularQueue regularQueue;
    EmergencyQueue emergencyQueue;
    PatientList patientList;
    int nextPatientID;
    
public:
    HospitalSystem() {
        nextPatientID = 1001;
    }
    
    // Initialize system
    void initialize() {
        cout << "\n----------------------------------------------------------------\n";
        cout << "       HOSPITAL PATIENT QUEUE MANAGEMENT SYSTEM\n";
        cout << "----------------------------------------------------------------\n";
        
        // Load existing data
        patientList.loadFromFile();
        
        // Find maximum ID for nextPatientID
        // This would require scanning patientList
        // For simplicity, we'll start from 1001 + count
        nextPatientID = 1001 + patientList.getCount();
        
        cout << "\nSystem initialized successfully!\n";
        cout << "Next Patient ID: " << nextPatientID << endl;
    }
    
    // Register new patient
    void registerPatient() {
        Patient p;
        p.id = nextPatientID++;
        
        cout << "\n----------------------------------------\n";
        cout << "       PATIENT REGISTRATION\n";
        cout << "----------------------------------------\n";
        
        cout << "Patient ID: " << p.id << endl;
        cin.ignore();
        
        cout << "Full Name: ";
        cin.getline(p.name, 50);
        
        cout << "Age: ";
        cin >> p.age;
        
        cout << "Gender (M/F): ";
        cin >> p.gender;
        
        cout << "Problem Description: ";
        cin.ignore();
        cin.getline(p.problem, 100);
        
        cout << "Severity Level (1-10, 1=Normal, 10=Critical): ";
        cin >> p.severity;
        
        // Validate severity
        if (p.severity < 1) p.severity = 1;
        if (p.severity > 10) p.severity = 10;
        
        // Determine queue type based on severity
        if (p.severity >= 7) {
            p.queueType = 1; // Emergency
            if (emergencyQueue.enqueue(p)) {
                cout << "\n? Patient added to EMERGENCY QUEUE (Priority)\n";
            }
        } else {
            p.queueType = 0; // Regular
            if (regularQueue.enqueue(p)) {
                cout << "\n? Patient added to REGULAR QUEUE\n";
            }
        }
        
        // Add to patient list
        patientList.addPatient(p);
        
        cout << "\nRegistration Successful! Patient ID: " << p.id << endl;
    }
    
    // Add emergency patient directly
    void addEmergencyPatient() {
        Patient p;
        p.id = nextPatientID++;
        p.queueType = 1; // Emergency
        
        cout << "\n----------------------------------------\n";
        cout << "       EMERGENCY PATIENT REGISTRATION\n";
        cout << "----------------------------------------\n";
        
        cout << "Patient ID: " << p.id << endl;
        cin.ignore();
        
        cout << "Full Name: ";
        cin.getline(p.name, 50);
        
        cout << "Age: ";
        cin >> p.age;
        
        cout << "Gender (M/F): ";
        cin >> p.gender;
        
        cout << "Problem Description: ";
        cin.ignore();
        cin.getline(p.problem, 100);
        
        cout << "Severity Level (7-10): ";
        cin >> p.severity;
        
        // Force high severity for emergency
        if (p.severity < 7) p.severity = 7;
        if (p.severity > 10) p.severity = 10;
        
        if (emergencyQueue.enqueue(p)) {
            cout << "\n? EMERGENCY PATIENT added with HIGH PRIORITY!\n";
            patientList.addPatient(p);
        }
    }
    
    // Consult next patient
    void consultNextPatient() {
        cout << "\n----------------------------------------\n";
        cout << "       CONSULT NEXT PATIENT\n";
        cout << "----------------------------------------\n";
        
        // First check emergency queue
        if (!emergencyQueue.isEmpty()) {
            Patient p = emergencyQueue.dequeue();
            patientList.updateStatus(p.id, 1);
            cout << "\n?? CONSULTING EMERGENCY PATIENT:\n";
            patientList.displayPatient(p);
        }
        // Then check regular queue
        else if (!regularQueue.isEmpty()) {
            Patient p = regularQueue.dequeue();
            patientList.updateStatus(p.id, 1);
            cout << "\n?? CONSULTING REGULAR PATIENT:\n";
            patientList.displayPatient(p);
        }
        else {
            cout << "\n? No patients waiting for consultation.\n";
        }
    }
    
    // View current queues
    void viewQueues() {
        cout << "\n----------------------------------------------------------------\n";
        cout << "              CURRENT QUEUE STATUS\n";
        cout << "----------------------------------------------------------------\n";
        
        emergencyQueue.display();
        cout << endl;
        regularQueue.display();
        
        cout << "\n----------------------------------------\n";
        cout << "        QUEUE STATISTICS\n";
        cout << "----------------------------------------\n";
        cout << "Emergency Patients: " << emergencyQueue.getCount() << endl;
        cout << "Regular Patients: " << regularQueue.getCount() << endl;
        cout << "Total Waiting: " << emergencyQueue.getCount() + regularQueue.getCount() << endl;
    }
    
    // Search patient
    void searchPatient() {
        int choice;
        cout << "\n----------------------------------------\n";
        cout << "           SEARCH PATIENT\n";
        cout << "----------------------------------------\n";
        cout << "1. Search by Patient ID\n";
        cout << "2. Search by Name\n";
        cout << "Enter choice: ";
        cin >> choice;
        
        if (choice == 1) {
            int id;
            cout << "Enter Patient ID: ";
            cin >> id;
            
            Patient* p = patientList.searchPatient(id);
            if (p != NULL) {
                patientList.displayPatient(*p);
            } else {
                cout << "\n? Patient not found!\n";
            }
        }
        else if (choice == 2) {
            char name[50];
            cout << "Enter Patient Name: ";
            cin.ignore();
            cin.getline(name, 50);
            
            patientList.searchPatientByName(name);
        }
        else {
            cout << "\n? Invalid choice!\n";
        }
    }
    
    // Discharge patient
    void dischargePatient() {
        int id;
        cout << "\nEnter Patient ID to discharge: ";
        cin >> id;
        
        if (patientList.updateStatus(id, 2)) {
            cout << "\n? Patient discharged successfully!\n";
        } else {
            cout << "\n? Patient not found!\n";
        }
    }
    
    // Generate reports
    void generateReports() {
        cout << "\n----------------------------------------\n";
        cout << "           SYSTEM REPORTS\n";
        cout << "----------------------------------------\n";
        cout << "Total Patients Registered: " << patientList.getCount() << endl;
        cout << "Patients in Emergency Queue: " << emergencyQueue.getCount() << endl;
        cout << "Patients in Regular Queue: " << regularQueue.getCount() << endl;
        cout << "Total Waiting Patients: " 
             << emergencyQueue.getCount() + regularQueue.getCount() << endl;
        
        // Display next patient from each queue
        cout << "\nNext Emergency Patient: ";
        if (!emergencyQueue.isEmpty()) {
            Patient p = emergencyQueue.peek();
            cout << p.name << " (Severity: " << p.severity << ")" << endl;
        } else {
            cout << "None" << endl;
        }
        
        cout << "Next Regular Patient: ";
        if (!regularQueue.isEmpty()) {
            Patient p = regularQueue.peek();
            cout << p.name << " (Arrived: " 
                 << timeToString(p.arrivalTime) << ")" << endl;
        } else {
            cout << "None" << endl;
        }
    }
    
    // View all patients
    void viewAllPatients() {
        patientList.displayAll();
    }
    
    // Save all data
    void saveAllData() {
        patientList.saveToFile();
        cout << "\n? All system data saved successfully!\n";
    }
    
    // Admin login
    bool adminLogin() {
        string username, password;
        int attempts = 3;
        
        cout << "\n----------------------------------------\n";
        cout << "            ADMIN LOGIN\n";
        cout << "----------------------------------------\n";
        
        while (attempts > 0) {
            cout << "Username: ";
            cin >> username;
            cout << "Password: ";
            cin >> password;
            
            if (username == ADMIN_USER && password == ADMIN_PASS) {
                cout << "\n? Login successful!\n";
                return true;
            } else {
                attempts--;
                cout << "\n? Invalid credentials. Attempts left: " << attempts << endl;
            }
        }
        
        cout << "\n? Maximum login attempts reached. Access denied!\n";
        return false;
    }
    
    // Main menu
    void mainMenu() {
        int choice;
        
        do {
            cout << "\n----------------------------------------------------------------\n";
            cout << "                HOSPITAL QUEUE MANAGEMENT SYSTEM\n";
            cout << "----------------------------------------------------------------\n";
            cout << "1. Register New Patient\n";
            cout << "2. View Current Queues\n";
            cout << "3. Add Emergency Patient\n";
            cout << "4. Consult Next Patient\n";
            cout << "5. Search Patient\n";
            cout << "6. Generate Reports\n";
            cout << "7. View All Patients\n";
            cout << "8. Discharge Patient\n";
            cout << "9. Save Data\n";
            cout << "10. Exit\n";
            cout << "----------------------------------------\n";
            cout << "Enter choice (1-10): ";
            cin >> choice;
            
            switch (choice) {
                case 1: registerPatient(); break;
                case 2: viewQueues(); break;
                case 3: addEmergencyPatient(); break;
                case 4: consultNextPatient(); break;
                case 5: searchPatient(); break;
                case 6: generateReports(); break;
                case 7: viewAllPatients(); break;
                case 8: dischargePatient(); break;
                case 9: saveAllData(); break;
                case 10: 
                    cout << "\nExiting system...\n";
                    break;
                default:
                    cout << "\n? Invalid choice! Please try again.\n";
            }
            
            if (choice != 10) {
                cout << "\nPress Enter to continue...";
                cin.ignore();
                cin.get();
            }
            
        } while (choice != 10);
    }
};

// ====================== MAIN FUNCTION ======================
int main() {
    HospitalSystem hospital;
    
    // Initialize system
    hospital.initialize();
    
    // Admin login
    if (!hospital.adminLogin()) {
        cout << "\nPress Enter to exit...";
        cin.ignore();
        cin.get();
        return 0;
    }
    
    // Run main menu
    hospital.mainMenu();
    
    // Ask to save before exit
    char save;
    cout << "\nSave data before exiting? (y/n): ";
    cin >> save;
    if (save == 'y' || save == 'Y') {
        hospital.saveAllData();
    }
    
    cout << "\nThank you for using Hospital Queue Management System!\n";
    cout << "Goodbye!\n";
    
    return 0;
}