/*
============================================================
 ONLINE EXAMINATION & RESULT PROCESSING SYSTEM
 Developed using C++ with DSA Implementation
 Features: Automatic Grading, Rank Calculation, Merit List
============================================================
*/

#include <iostream>
#include <fstream>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <windows.h>
#include <cctype>
#include <string>
using namespace std;

// ====================== CONSTANTS ======================
const int MAX_STUDENTS = 500;
const int MAX_QUESTIONS = 50;
const int MAX_SUBJECTS = 10;
const string ADMIN_USER = "admin";
const string ADMIN_PASS = "admin123";
const int PHONE_LENGTH = 10;  // Fixed phone number length

// ====================== COLOR CODES ======================
enum Color {
    BLACK = 0,
    BLUE = 1,
    GREEN = 2,
    CYAN = 3,
    RED = 4,
    MAGENTA = 5,
    YELLOW = 6,
    WHITE = 7,
    GRAY = 8,
    BRIGHT_BLUE = 9,
    BRIGHT_GREEN = 10,
    BRIGHT_CYAN = 11,
    BRIGHT_RED = 12,
    BRIGHT_MAGENTA = 13,
    BRIGHT_YELLOW = 14,
    BRIGHT_WHITE = 15
};

// ====================== UTILITY FUNCTIONS ======================
void setColor(int color) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
}

void sleep(int milliseconds) {
    Sleep(milliseconds);
}

void clearScreen() {
    system("cls");
}

void printHeader(const string& title) {
    setColor(BRIGHT_CYAN);
    cout << "\n============================================================\n";
    cout << "                   " << title << endl;
    cout << "============================================================\n";
    setColor(WHITE);
}

void printSuccess(const string& message) {
    setColor(BRIGHT_GREEN);
    cout << "[SUCCESS] " << message << endl;
    setColor(WHITE);
}

void printError(const string& message) {
    setColor(BRIGHT_RED);
    cout << "[ERROR] " << message << endl;
    setColor(WHITE);
}

void printWarning(const string& message) {
    setColor(BRIGHT_YELLOW);
    cout << "[WARNING] " << message << endl;
    setColor(WHITE);
}

void printInfo(const string& message) {
    setColor(BRIGHT_CYAN);
    cout << "[INFO] " << message << endl;
    setColor(WHITE);
}

void loadingAnimation(const string& message, int duration = 1000) {
    setColor(BRIGHT_YELLOW);
    cout << "\n" << message;
    for(int i = 0; i < 3; i++) {
        cout << ".";
        Sleep(duration/3);
    }
    cout << endl;
    setColor(WHITE);
}

// ====================== INPUT VALIDATION FUNCTIONS ======================
bool isValidEmail(const string& email) {
    // Simple email validation
    size_t at_pos = email.find('@');
    size_t dot_pos = email.find('.', at_pos);
    
    return (at_pos != string::npos && 
            dot_pos != string::npos && 
            dot_pos > at_pos + 1 && 
            dot_pos < email.length() - 1);
}

bool isValidPhone(const string& phone) {
    // Check if phone is exactly PHONE_LENGTH digits and all are numbers
    if (phone.length() != PHONE_LENGTH) return false;
    
    for (char c : phone) {
        if (!isdigit(c)) return false;
    }
    return true;
}

bool isInteger(const string& str) {
    if (str.empty()) return false;
    
    for (char c : str) {
        if (!isdigit(c)) return false;
    }
    return true;
}

// ====================== QUESTION STRUCTURE ======================
struct Question {
    int questionID;
    char questionText[500];
    char optionA[100];
    char optionB[100];
    char optionC[100];
    char optionD[100];
    char correctAnswer;
    int marks;
    char subject[50];
    
    Question() {
        questionID = 0;
        strcpy(questionText, "");
        strcpy(optionA, "");
        strcpy(optionB, "");
        strcpy(optionC, "");
        strcpy(optionD, "");
        correctAnswer = 'A';
        marks = 1;
        strcpy(subject, "");
    }
    
    void displayQuestion() const {
        setColor(BRIGHT_WHITE);
        cout << "\nQuestion ID: " << questionID << endl;
        cout << "Subject: " << subject << endl;
        cout << "Marks: " << marks << endl;
        cout << "Question: " << questionText << endl;
        cout << "A) " << optionA << endl;
        cout << "B) " << optionB << endl;
        cout << "C) " << optionC << endl;
        cout << "D) " << optionD << endl;
        cout << "Correct Answer: " << correctAnswer << endl;
    }
};

// ====================== STUDENT STRUCTURE ======================
struct Student {
    int studentID;
    char name[50];
    char rollNumber[20];
    char email[50];
    char contact[15];
    char course[50];
    int semester;
    
    Student() {
        studentID = 0;
        strcpy(name, "");
        strcpy(rollNumber, "");
        strcpy(email, "");
        strcpy(contact, "");
        strcpy(course, "");
        semester = 1;
    }
    
    void displayStudent() const {
        setColor(BRIGHT_MAGENTA);
        cout << "\n============================================================\n";
        cout << "                    STUDENT DETAILS\n";
        cout << "============================================================\n";
        setColor(WHITE);
        
        cout << "  Student ID:     " << studentID << endl;
        cout << "  Name:           " << name << endl;
        cout << "  Roll Number:    " << rollNumber << endl;
        cout << "  Email:          " << email << endl;
        cout << "  Contact:        " << contact << endl;
        cout << "  Course:         " << course << endl;
        cout << "  Semester:       " << semester << endl;
        
        setColor(BRIGHT_MAGENTA);
        cout << "============================================================\n";
        setColor(WHITE);
    }
    
    void displayBrief() const {
        cout << left << setw(10) << studentID 
             << setw(25) << name 
             << setw(15) << rollNumber
             << setw(20) << course
             << setw(10) << semester << endl;
    }
};

// ====================== EXAM RESULT STRUCTURE ======================
struct ExamResult {
    int resultID;
    int studentID;
    char studentName[50];
    char rollNumber[20];
    char examDate[20];
    char subject[50];
    int totalQuestions;
    int attempted;
    int correctAnswers;
    int wrongAnswers;
    float percentage;
    char grade;
    int totalMarks;
    int obtainedMarks;
    int rank;
    
    ExamResult() {
        resultID = 0;
        studentID = 0;
        strcpy(studentName, "");
        strcpy(rollNumber, "");
        strcpy(examDate, "");
        strcpy(subject, "");
        totalQuestions = 0;
        attempted = 0;
        correctAnswers = 0;
        wrongAnswers = 0;
        percentage = 0.0;
        grade = 'F';
        totalMarks = 0;
        obtainedMarks = 0;
        rank = 0;
    }
    
    void displayResult() const {
        setColor(BRIGHT_YELLOW);
        cout << "\n============================================================\n";
        cout << "                      EXAM RESULT\n";
        cout << "============================================================\n";
        setColor(WHITE);
        
        cout << "  Result ID:          " << resultID << endl;
        cout << "  Student ID:         " << studentID << endl;
        cout << "  Name:               " << studentName << endl;
        cout << "  Roll Number:        " << rollNumber << endl;
        cout << "  Exam Date:          " << examDate << endl;
        cout << "  Subject:            " << subject << endl;
        cout << "  Total Questions:    " << totalQuestions << endl;
        cout << "  Attempted:          " << attempted << endl;
        cout << "  Correct Answers:    " << correctAnswers << endl;
        cout << "  Wrong Answers:      " << wrongAnswers << endl;
        cout << "  Total Marks:        " << totalMarks << endl;
        cout << "  Obtained Marks:     ";
        
        if (obtainedMarks >= (totalMarks * 0.4)) {
            setColor(BRIGHT_GREEN);
        } else {
            setColor(BRIGHT_RED);
        }
        cout << obtainedMarks << endl;
        setColor(WHITE);
        
        cout << "  Percentage:         " << fixed << setprecision(2) << percentage << "%" << endl;
        cout << "  Grade:              ";
        
        switch(grade) {
            case 'A': setColor(BRIGHT_GREEN); break;
            case 'B': setColor(BRIGHT_CYAN); break;
            case 'C': setColor(BRIGHT_YELLOW); break;
            case 'D': setColor(BRIGHT_MAGENTA); break;
            default: setColor(BRIGHT_RED); break;
        }
        cout << grade << endl;
        setColor(WHITE);
        
        if (rank > 0) {
            cout << "  Rank:               " << rank << endl;
        }
        
        setColor(BRIGHT_YELLOW);
        cout << "============================================================\n";
        setColor(WHITE);
    }
    
    void displayBrief() const {
        cout << left << setw(12) << resultID 
             << setw(25) << studentName 
             << setw(15) << rollNumber
             << setw(15) << subject
             << setw(8) << obtainedMarks << "/" << totalMarks
             << setw(10) << fixed << setprecision(2) << percentage << "%"
             << setw(6) << grade;
        
        if (rank > 0) {
            cout << setw(8) << rank;
        }
        cout << endl;
    }
};

// ====================== QUESTION BANK MANAGEMENT ======================
class QuestionBank {
private:
    Question questions[MAX_QUESTIONS];
    int questionCount;
    
public:
    QuestionBank() {
        questionCount = 0;
    }
    
    // Add new question
    bool addQuestion() {
        if (questionCount >= MAX_QUESTIONS) {
            printError("Cannot add more questions. Maximum limit reached!");
            return false;
        }
        
        Question newQuestion;
        newQuestion.questionID = 1000 + questionCount + 1;
        
        setColor(BRIGHT_WHITE);
        cout << "\nQuestion ID: " << newQuestion.questionID << endl;
        cin.ignore();
        
        cout << "Enter Subject: ";
        cin.getline(newQuestion.subject, 50);
        
        cout << "Enter Question Text: ";
        cin.getline(newQuestion.questionText, 500);
        
        cout << "Enter Option A: ";
        cin.getline(newQuestion.optionA, 100);
        
        cout << "Enter Option B: ";
        cin.getline(newQuestion.optionB, 100);
        
        cout << "Enter Option C: ";
        cin.getline(newQuestion.optionC, 100);
        
        cout << "Enter Option D: ";
        cin.getline(newQuestion.optionD, 100);
        
        cout << "Enter Correct Answer (A/B/C/D): ";
        cin >> newQuestion.correctAnswer;
        newQuestion.correctAnswer = toupper(newQuestion.correctAnswer);
        
        cout << "Enter Marks for this question: ";
        cin >> newQuestion.marks;
        
        questions[questionCount] = newQuestion;
        questionCount++;
        
        loadingAnimation("Adding question to bank");
        printSuccess("Question added successfully! Question ID: " + to_string(newQuestion.questionID));
        return true;
    }
    
    // Display all questions
    void displayAllQuestions() {
        if (questionCount == 0) {
            printInfo("No questions available in the bank.");
            return;
        }
        
        setColor(BRIGHT_CYAN);
        cout << "\n========================================================================================================\n";
        cout << "                                 QUESTION BANK\n";
        cout << "========================================================================================================\n";
        cout << left << setw(12) << "Question ID" << setw(20) << "Subject" 
             << setw(50) << "Question" << setw(8) << "Marks" << "Correct Answer" << endl;
        cout << "--------------------------------------------------------------------------------------------------------\n";
        setColor(WHITE);
        
        for (int i = 0; i < questionCount; i++) {
            cout << left << setw(12) << questions[i].questionID 
                 << setw(20) << questions[i].subject;
            
            // Display only first 45 characters of question
            string qText = questions[i].questionText;
            if (qText.length() > 45) {
                qText = qText.substr(0, 42) + "...";
            }
            cout << setw(50) << qText 
                 << setw(8) << questions[i].marks 
                 << questions[i].correctAnswer << endl;
        }
        
        setColor(BRIGHT_CYAN);
        cout << "========================================================================================================\n";
        setColor(BRIGHT_YELLOW);
        cout << "\nTotal Questions: " << questionCount << endl;
        setColor(WHITE);
    }
    
    // Search question by ID
    Question* searchQuestion(int questionID) {
        for (int i = 0; i < questionCount; i++) {
            if (questions[i].questionID == questionID) {
                return &questions[i];
            }
        }
        return NULL;
    }
    
    // Get questions by subject
    vector<Question> getQuestionsBySubject(const char* subject) {
        vector<Question> subjectQuestions;
        for (int i = 0; i < questionCount; i++) {
            if (strcmp(questions[i].subject, subject) == 0) {
                subjectQuestions.push_back(questions[i]);
            }
        }
        return subjectQuestions;
    }
    
    // Delete question
    bool deleteQuestion(int questionID) {
        for (int i = 0; i < questionCount; i++) {
            if (questions[i].questionID == questionID) {
                // Shift questions left
                for (int j = i; j < questionCount - 1; j++) {
                    questions[j] = questions[j + 1];
                }
                questionCount--;
                printSuccess("Question deleted successfully!");
                return true;
            }
        }
        printError("Question not found!");
        return false;
    }
    
    // Get question count
    int getQuestionCount() { return questionCount; }
    
    // Save questions to file
    void saveToFile() {
        ofstream file("questions.dat", ios::binary);
        if (!file) {
            printError("Error saving questions data!");
            return;
        }
        
        for (int i = 0; i < questionCount; i++) {
            file.write(reinterpret_cast<char*>(&questions[i]), sizeof(Question));
        }
        
        file.close();
        printSuccess("Questions data saved successfully!");
    }
    
    // Load questions from file
    void loadFromFile() {
        ifstream file("questions.dat", ios::binary);
        if (!file) {
            printInfo("No previous questions data found.");
            addDefaultQuestions(); // Add default questions if no file exists
            return;
        }
        
        Question question;
        while (file.read(reinterpret_cast<char*>(&question), sizeof(Question))) {
            if (questionCount < MAX_QUESTIONS) {
                questions[questionCount++] = question;
            }
        }
        
        file.close();
        printSuccess("Loaded " + to_string(questionCount) + " questions.");
    }
    
    // Add default questions
    void addDefaultQuestions() {
        // C++ Programming Questions
        addDefaultQuestion(1001, "C++ Programming", "What is the output of cout << 5/2; in C++?", "2", "2.5", "2.0", "Error", 'A', 2);
        addDefaultQuestion(1002, "C++ Programming", "Which keyword is used to define a class in C++?", "class", "struct", "object", "define", 'A', 2);
        addDefaultQuestion(1003, "C++ Programming", "What is the size of int data type in C++?", "2 bytes", "4 bytes", "8 bytes", "Depends on compiler", 'D', 2);
        
        // Data Structures Questions
        addDefaultQuestion(1004, "Data Structures", "Which data structure uses LIFO principle?", "Queue", "Stack", "Tree", "Graph", 'B', 3);
        addDefaultQuestion(1005, "Data Structures", "What is time complexity of binary search?", "O(n)", "O(log n)", "O(n^2)", "O(1)", 'B', 3);
        
        // Mathematics Questions
        addDefaultQuestion(1006, "Mathematics", "What is value of pi (p)?", "3.14", "22/7", "Both A and B", "None", 'C', 1);
        addDefaultQuestion(1007, "Mathematics", "Derivative of x^2 is?", "x", "2x", "x^3/3", "x^2", 'B', 2);
        
        printSuccess("Added " + to_string(questionCount) + " default questions.");
    }
    
private:
    void addDefaultQuestion(int id, const char* subj, const char* qText, 
                           const char* a, const char* b, const char* c, 
                           const char* d, char ans, int mrks) {
        if (questionCount >= MAX_QUESTIONS) return;
        
        Question q;
        q.questionID = id;
        strcpy(q.subject, subj);
        strcpy(q.questionText, qText);
        strcpy(q.optionA, a);
        strcpy(q.optionB, b);
        strcpy(q.optionC, c);
        strcpy(q.optionD, d);
        q.correctAnswer = ans;
        q.marks = mrks;
        
        questions[questionCount++] = q;
    }
};

// ====================== STUDENT MANAGEMENT ======================
class StudentManager {
private:
    Student students[MAX_STUDENTS];
    int studentCount;
    
public:
    StudentManager() {
        studentCount = 0;
    }
    
    // Add new student with validation
    bool addStudent() {
        if (studentCount >= MAX_STUDENTS) {
            printError("Cannot add more students. Maximum limit reached!");
            return false;
        }
        
        Student newStudent;
        newStudent.studentID = 2000 + studentCount + 1;
        
        setColor(BRIGHT_WHITE);
        cout << "\nStudent ID: " << newStudent.studentID << endl;
        cin.ignore();
        
        // Name input
        cout << "Enter Full Name: ";
        cin.getline(newStudent.name, 50);
        
        // Roll number input
        cout << "Enter Roll Number: ";
        cin.getline(newStudent.rollNumber, 20);
        
        // Email input with validation
        string emailInput;
        while (true) {
            cout << "Enter Email: ";
            cin.getline(newStudent.email, 50);
            emailInput = newStudent.email;
            
            if (isValidEmail(emailInput)) {
                break;
            } else {
                printError("Invalid email format! Please enter a valid email (e.g., name@domain.com)");
            }
        }
        
        // Phone number input with validation
        string phoneInput;
        while (true) {
            cout << "Enter Contact Number (" << PHONE_LENGTH << " digits): ";
            cin.getline(newStudent.contact, 15);
            phoneInput = newStudent.contact;
            
            if (isValidPhone(phoneInput)) {
                break;
            } else {
                printError("Invalid phone number! Please enter exactly " + to_string(PHONE_LENGTH) + " digits.");
            }
        }
        
        cout << "Enter Course: ";
        cin.getline(newStudent.course, 50);
        
        // Semester input with validation
        string semInput;
        while (true) {
            cout << "Enter Semester (1-8): ";
            getline(cin, semInput);
            
            if (isInteger(semInput)) {
                int sem = stoi(semInput);
                if (sem >= 1 && sem <= 8) {
                    newStudent.semester = sem;
                    break;
                } else {
                    printError("Semester must be between 1 and 8!");
                }
            } else {
                printError("Please enter a valid number for semester!");
            }
        }
        
        students[studentCount] = newStudent;
        studentCount++;
        
        loadingAnimation("Registering student");
        printSuccess("Student registered successfully! Student ID: " + to_string(newStudent.studentID));
        return true;
    }
    
    // Display all students
    void displayAllStudents() {
        if (studentCount == 0) {
            printInfo("No students registered.");
            return;
        }
        
        setColor(BRIGHT_MAGENTA);
        cout << "\n========================================================================================================\n";
        cout << "                                    ALL STUDENTS\n";
        cout << "========================================================================================================\n";
        cout << left << setw(10) << "Student ID" << setw(25) << "Name" 
             << setw(15) << "Roll Number" << setw(20) << "Course" 
             << setw(10) << "Semester" << endl;
        cout << "--------------------------------------------------------------------------------------------------------\n";
        setColor(WHITE);
        
        for (int i = 0; i < studentCount; i++) {
            students[i].displayBrief();
        }
        
        setColor(BRIGHT_MAGENTA);
        cout << "========================================================================================================\n";
        setColor(BRIGHT_YELLOW);
        cout << "\nTotal Students: " << studentCount << endl;
        setColor(WHITE);
    }
    
    // Search student by ID
    Student* searchStudent(int studentID) {
        for (int i = 0; i < studentCount; i++) {
            if (students[i].studentID == studentID) {
                return &students[i];
            }
        }
        return NULL;
    }
    
    // Search student by roll number
    Student* searchStudentByRoll(const char* rollNumber) {
        for (int i = 0; i < studentCount; i++) {
            if (strcmp(students[i].rollNumber, rollNumber) == 0) {
                return &students[i];
            }
        }
        return NULL;
    }
    
    // Update student
    bool updateStudent(int studentID) {
        Student* student = searchStudent(studentID);
        if (student == NULL) {
            printError("Student not found!");
            return false;
        }
        
        cout << "\nUpdating Student ID: " << studentID << endl;
        cout << "Current Name: " << student->name << endl;
        cin.ignore();
        
        cout << "Enter New Name (press Enter to keep current): ";
        char newName[50];
        cin.getline(newName, 50);
        if (strlen(newName) > 0) {
            strcpy(student->name, newName);
        }
        
        // Email update with validation
        string emailInput;
        while (true) {
            cout << "Enter New Email (press Enter to keep current): ";
            char newEmail[50];
            cin.getline(newEmail, 50);
            
            if (strlen(newEmail) == 0) {
                break; // Keep current email
            }
            
            emailInput = newEmail;
            if (isValidEmail(emailInput)) {
                strcpy(student->email, newEmail);
                break;
            } else {
                printError("Invalid email format! Please enter a valid email.");
            }
        }
        
        printSuccess("Student updated successfully!");
        return true;
    }
    
    // Get student count
    int getStudentCount() { return studentCount; }
    
    // Save students to file
    void saveToFile() {
        ofstream file("students.dat", ios::binary);
        if (!file) {
            printError("Error saving students data!");
            return;
        }
        
        for (int i = 0; i < studentCount; i++) {
            file.write(reinterpret_cast<char*>(&students[i]), sizeof(Student));
        }
        
        file.close();
        printSuccess("Students data saved successfully!");
    }
    
    // Load students from file
    void loadFromFile() {
        ifstream file("students.dat", ios::binary);
        if (!file) {
            printInfo("No previous students data found.");
            addDefaultStudents(); // Add default students if no file exists
            return;
        }
        
        Student student;
        while (file.read(reinterpret_cast<char*>(&student), sizeof(Student))) {
            if (studentCount < MAX_STUDENTS) {
                students[studentCount++] = student;
            }
        }
        
        file.close();
        printSuccess("Loaded " + to_string(studentCount) + " students.");
    }
    
    // Add default students
    void addDefaultStudents() {
        addDefaultStudent(2001, "John Smith", "CS2021001", "john.smith@university.edu", "9876543210", "Computer Science", 3);
        addDefaultStudent(2002, "Emma Johnson", "CS2021002", "emma.johnson@university.edu", "9876543211", "Computer Science", 3);
        addDefaultStudent(2003, "Michael Brown", "CS2021003", "michael.brown@university.edu", "9876543212", "Computer Science", 3);
        addDefaultStudent(2004, "Sarah Davis", "IT2021001", "sarah.davis@university.edu", "9876543213", "Information Technology", 4);
        addDefaultStudent(2005, "David Wilson", "IT2021002", "david.wilson@university.edu", "9876543214", "Information Technology", 4);
        addDefaultStudent(2006, "Lisa Anderson", "ME2021001", "lisa.anderson@university.edu", "9876543215", "Mechanical Engineering", 2);
        addDefaultStudent(2007, "Robert Taylor", "CE2021001", "robert.taylor@university.edu", "9876543216", "Civil Engineering", 5);
        addDefaultStudent(2008, "Maria Thomas", "EE2021001", "maria.thomas@university.edu", "9876543217", "Electrical Engineering", 3);
        addDefaultStudent(2009, "James Jackson", "CS2021004", "james.jackson@university.edu", "9876543218", "Computer Science", 3);
        addDefaultStudent(2010, "Patricia White", "CS2021005", "patricia.white@university.edu", "9876543219", "Computer Science", 3);
        
        printSuccess("Added " + to_string(studentCount) + " default students.");
    }
    
private:
    void addDefaultStudent(int id, const char* name, const char* roll, 
                          const char* email, const char* contact, 
                          const char* course, int semester) {
        if (studentCount >= MAX_STUDENTS) return;
        
        Student s;
        s.studentID = id;
        strcpy(s.name, name);
        strcpy(s.rollNumber, roll);
        strcpy(s.email, email);
        strcpy(s.contact, contact);
        strcpy(s.course, course);
        s.semester = semester;
        
        students[studentCount++] = s;
    }
};

// ====================== EXAM MANAGEMENT ======================
class ExamManager {
private:
    ExamResult results[MAX_STUDENTS * 5]; // Each student can have multiple results
    int resultCount;
    QuestionBank* questionBank;
    StudentManager* studentManager;
    
public:
    ExamManager(QuestionBank* qb, StudentManager* sm) {
        resultCount = 0;
        questionBank = qb;
        studentManager = sm;
    }
    
    // Conduct exam for a student
    bool conductExam(int studentID, const char* subject) {
        Student* student = studentManager->searchStudent(studentID);
        if (student == NULL) {
            printError("Student not found!");
            return false;
        }
        
        vector<Question> subjectQuestions = questionBank->getQuestionsBySubject(subject);
        if (subjectQuestions.empty()) {
            printError("No questions found for subject: " + string(subject));
            return false;
        }
        
        // Get current date
        time_t now = time(0);
        tm* ltm = localtime(&now);
        char examDate[20];
        strftime(examDate, 20, "%d/%m/%Y", ltm);
        
        ExamResult newResult;
        newResult.resultID = 3000 + resultCount + 1;
        newResult.studentID = studentID;
        strcpy(newResult.studentName, student->name);
        strcpy(newResult.rollNumber, student->rollNumber);
        strcpy(newResult.examDate, examDate);
        strcpy(newResult.subject, subject);
        newResult.totalQuestions = subjectQuestions.size();
        newResult.totalMarks = 0;
        
        // Calculate total marks
        for (const auto& q : subjectQuestions) {
            newResult.totalMarks += q.marks;
        }
        
        clearScreen();
        printHeader("ONLINE EXAMINATION - " + string(subject));
        
        setColor(BRIGHT_WHITE);
        cout << "\nStudent Name: " << student->name << endl;
        cout << "Roll Number: " << student->rollNumber << endl;
        cout << "Subject: " << subject << endl;
        cout << "Total Questions: " << newResult.totalQuestions << endl;
        cout << "Total Marks: " << newResult.totalMarks << endl;
        cout << "\nInstructions:" << endl;
        cout << "1. Enter your answer as A, B, C, or D" << endl;
        cout << "2. Press X to skip a question" << endl;
        cout << "3. Each question has different marks" << endl;
        cout << "============================================================\n";
        
        sleep(2000);
        
        newResult.attempted = 0;
        newResult.correctAnswers = 0;
        newResult.wrongAnswers = 0;
        newResult.obtainedMarks = 0;
        
        // Conduct exam
        for (int i = 0; i < subjectQuestions.size(); i++) {
            const Question& q = subjectQuestions[i];
            
            setColor(BRIGHT_CYAN);
            cout << "\nQuestion " << (i + 1) << " of " << subjectQuestions.size() << " (Marks: " << q.marks << ")" << endl;
            cout << "============================================================\n";
            setColor(WHITE);
            
            cout << q.questionText << endl;
            cout << "A) " << q.optionA << endl;
            cout << "B) " << q.optionB << endl;
            cout << "C) " << q.optionC << endl;
            cout << "D) " << q.optionD << endl;
            
            char answer;
            cout << "\nYour answer (A/B/C/D/X to skip): ";
            cin >> answer;
            answer = toupper(answer);
            
            if (answer == 'X') {
                cout << "Question skipped." << endl;
            } else {
                newResult.attempted++;
                if (answer == q.correctAnswer) {
                    setColor(BRIGHT_GREEN);
                    cout << "Correct!" << endl;
                    setColor(WHITE);
                    newResult.correctAnswers++;
                    newResult.obtainedMarks += q.marks;
                } else {
                    setColor(BRIGHT_RED);
                    cout << "Wrong! Correct answer was: " << q.correctAnswer << endl;
                    setColor(WHITE);
                    newResult.wrongAnswers++;
                }
            }
            
            if (i < subjectQuestions.size() - 1) {
                cout << "\nPress Enter for next question...";
                cin.ignore();
                cin.get();
            }
        }
        
        // Calculate percentage and grade
        if (newResult.totalMarks > 0) {
            newResult.percentage = (static_cast<float>(newResult.obtainedMarks) / newResult.totalMarks) * 100;
            newResult.grade = calculateGrade(newResult.percentage);
        }
        
        results[resultCount] = newResult;
        resultCount++;
        
        loadingAnimation("Processing exam results");
        printSuccess("Exam completed successfully! Result ID: " + to_string(newResult.resultID));
        
        // Display result immediately
        newResult.displayResult();
        
        return true;
    }
    
    // Calculate grade based on percentage
    char calculateGrade(float percentage) {
        if (percentage >= 90) return 'A';
        else if (percentage >= 80) return 'B';
        else if (percentage >= 70) return 'C';
        else if (percentage >= 60) return 'D';
        else if (percentage >= 40) return 'E';
        else return 'F';
    }
    
    // Display all results
    void displayAllResults() {
        if (resultCount == 0) {
            printInfo("No exam results available.");
            return;
        }
        
        setColor(BRIGHT_YELLOW);
        cout << "\n======================================================================================================================\n";
        cout << "                                          ALL EXAM RESULTS\n";
        cout << "======================================================================================================================\n";
        cout << left << setw(12) << "Result ID" << setw(25) << "Student Name" 
             << setw(15) << "Roll Number" << setw(15) << "Subject"
             << setw(15) << "Marks" << setw(12) << "Percentage" 
             << setw(8) << "Grade" << "Rank" << endl;
        cout << "----------------------------------------------------------------------------------------------------------------------\n";
        setColor(WHITE);
        
        for (int i = 0; i < resultCount; i++) {
            results[i].displayBrief();
        }
        
        setColor(BRIGHT_YELLOW);
        cout << "======================================================================================================================\n";
        setColor(BRIGHT_YELLOW);
        cout << "\nTotal Results: " << resultCount << endl;
        setColor(WHITE);
    }
    
    // Search result by student ID
    void searchResultByStudent(int studentID) {
        bool found = false;
        for (int i = 0; i < resultCount; i++) {
            if (results[i].studentID == studentID) {
                results[i].displayResult();
                found = true;
            }
        }
        if (!found) {
            printError("No results found for Student ID: " + to_string(studentID));
        }
    }
    
    // Calculate ranks for a specific subject
    void calculateRanks(const char* subject) {
        // Create a vector of pointers to results for this subject
        vector<ExamResult*> subjectResults;
        
        for (int i = 0; i < resultCount; i++) {
            if (strcmp(results[i].subject, subject) == 0) {
                subjectResults.push_back(&results[i]);
                results[i].rank = 0; // Reset rank
            }
        }
        
        if (subjectResults.empty()) {
            printError("No results found for subject: " + string(subject));
            return;
        }
        
        // Sort results by obtained marks (descending)
        sort(subjectResults.begin(), subjectResults.end(), 
             [](ExamResult* a, ExamResult* b) {
                 return a->obtainedMarks > b->obtainedMarks;
             });
        
        // Assign ranks
        int currentRank = 1;
        int previousMarks = -1;
        int sameRankCount = 0;
        
        for (int i = 0; i < subjectResults.size(); i++) {
            if (subjectResults[i]->obtainedMarks != previousMarks) {
                currentRank += sameRankCount;
                sameRankCount = 0;
            }
            
            subjectResults[i]->rank = currentRank;
            previousMarks = subjectResults[i]->obtainedMarks;
            sameRankCount++;
        }
        
        loadingAnimation("Calculating ranks for " + string(subject));
        printSuccess("Ranks calculated successfully for " + string(subject));
    }
    
    // Generate merit list for a subject
    void generateMeritList(const char* subject, int topN = 10) {
        vector<ExamResult*> subjectResults;
        
        for (int i = 0; i < resultCount; i++) {
            if (strcmp(results[i].subject, subject) == 0) {
                subjectResults.push_back(&results[i]);
            }
        }
        
        if (subjectResults.empty()) {
            printError("No results found for subject: " + string(subject));
            return;
        }
        
        // Sort by obtained marks (descending)
        sort(subjectResults.begin(), subjectResults.end(), 
             [](ExamResult* a, ExamResult* b) {
                 return a->obtainedMarks > b->obtainedMarks;
             });
        
        // Display top N students
        int displayCount = min(topN, (int)subjectResults.size());
        
        setColor(BRIGHT_GREEN);
        cout << "\n======================================================================================================================\n";
        cout << "                         MERIT LIST - " << subject << " (Top " << displayCount << ")\n";
        cout << "======================================================================================================================\n";
        cout << left << setw(6) << "Rank" << setw(25) << "Student Name" 
             << setw(15) << "Roll Number" << setw(15) << "Marks"
             << setw(12) << "Percentage" << setw(8) << "Grade" << endl;
        cout << "----------------------------------------------------------------------------------------------------------------------\n";
        setColor(WHITE);
        
        for (int i = 0; i < displayCount; i++) {
            cout << left << setw(6) << (i + 1)
                 << setw(25) << subjectResults[i]->studentName
                 << setw(15) << subjectResults[i]->rollNumber
                 << setw(8) << subjectResults[i]->obtainedMarks << "/" << subjectResults[i]->totalMarks
                 << setw(12) << fixed << setprecision(2) << subjectResults[i]->percentage << "%"
                 << setw(8) << subjectResults[i]->grade << endl;
        }
        
        setColor(BRIGHT_GREEN);
        cout << "======================================================================================================================\n";
        setColor(WHITE);
    }
    
    // Get overall statistics
    void displayStatistics() {
        if (resultCount == 0) {
            printInfo("No exam results available for statistics.");
            return;
        }
        
        int totalPassed = 0;
        int totalFailed = 0;
        float totalPercentage = 0;
        int highestMarks = 0;
        char highestStudent[50] = "";
        
        // Count grades
        int gradeA = 0, gradeB = 0, gradeC = 0, gradeD = 0, gradeE = 0, gradeF = 0;
        
        for (int i = 0; i < resultCount; i++) {
            totalPercentage += results[i].percentage;
            
            if (results[i].obtainedMarks > highestMarks) {
                highestMarks = results[i].obtainedMarks;
                strcpy(highestStudent, results[i].studentName);
            }
            
            if (results[i].percentage >= 40) {
                totalPassed++;
            } else {
                totalFailed++;
            }
            
            switch(results[i].grade) {
                case 'A': gradeA++; break;
                case 'B': gradeB++; break;
                case 'C': gradeC++; break;
                case 'D': gradeD++; break;
                case 'E': gradeE++; break;
                case 'F': gradeF++; break;
            }
        }
        
        float averagePercentage = totalPercentage / resultCount;
        
        setColor(BRIGHT_CYAN);
        cout << "\n============================================================\n";
        cout << "                  EXAM STATISTICS\n";
        cout << "============================================================\n";
        setColor(WHITE);
        
        cout << "\n  Total Exams Conducted:   " << resultCount << endl;
        cout << "  Average Percentage:     " << fixed << setprecision(2) << averagePercentage << "%" << endl;
        cout << "  Total Passed:           " << totalPassed << " (" << fixed << setprecision(1) 
             << (static_cast<float>(totalPassed) / resultCount * 100) << "%)" << endl;
        cout << "  Total Failed:           " << totalFailed << " (" << fixed << setprecision(1) 
             << (static_cast<float>(totalFailed) / resultCount * 100) << "%)" << endl;
        cout << "  Highest Marks:          " << highestMarks << " by " << highestStudent << endl;
        
        cout << "\n  Grade Distribution:\n";
        cout << "    A Grade: " << gradeA << " students" << endl;
        cout << "    B Grade: " << gradeB << " students" << endl;
        cout << "    C Grade: " << gradeC << " students" << endl;
        cout << "    D Grade: " << gradeD << " students" << endl;
        cout << "    E Grade: " << gradeE << " students" << endl;
        cout << "    F Grade: " << gradeF << " students" << endl;
        
        setColor(BRIGHT_CYAN);
        cout << "\n============================================================\n";
        setColor(WHITE);
    }
    
    // Get result count
    int getResultCount() { return resultCount; }
    
    // Save results to file
    void saveToFile() {
        ofstream file("results.dat", ios::binary);
        if (!file) {
            printError("Error saving results data!");
            return;
        }
        
        for (int i = 0; i < resultCount; i++) {
            file.write(reinterpret_cast<char*>(&results[i]), sizeof(ExamResult));
        }
        
        file.close();
        printSuccess("Results data saved successfully!");
    }
    
    // Load results from file
    void loadFromFile() {
        ifstream file("results.dat", ios::binary);
        if (!file) {
            printInfo("No previous results data found.");
            return;
        }
        
        ExamResult result;
        while (file.read(reinterpret_cast<char*>(&result), sizeof(ExamResult))) {
            if (resultCount < (MAX_STUDENTS * 5)) {
                results[resultCount++] = result;
            }
        }
        
        file.close();
        printSuccess("Loaded " + to_string(resultCount) + " results.");
    }
};

// ====================== EXAMINATION SYSTEM ======================
class ExaminationSystem {
private:
    QuestionBank questionBank;
    StudentManager studentManager;
    ExamManager* examManager;
    
public:
    ExaminationSystem() : examManager(new ExamManager(&questionBank, &studentManager)) {}
    
    ~ExaminationSystem() {
        delete examManager;
    }
    
    // Initialize system
    void initialize() {
        clearScreen();
        printHeader("ONLINE EXAMINATION & RESULT PROCESSING SYSTEM");
        
        setColor(BRIGHT_YELLOW);
        cout << "\nDEVELOPED USING C++ WITH DATA STRUCTURES IMPLEMENTATION\n";
        cout << "   Automatic Grading, Rank Calculation & Merit List Generation\n";
        cout << "============================================================\n";
        setColor(WHITE);
        
        loadingAnimation("Initializing system components", 1500);
        
        // Load existing data
        questionBank.loadFromFile();
        studentManager.loadFromFile();
        examManager->loadFromFile();
        
        printSuccess("System initialized successfully!");
        sleep(1500);
    }
    
    // Admin login
    bool adminLogin() {
        clearScreen();
        printHeader("ADMINISTRATOR LOGIN");
        
        string username, password;
        int attempts = 3;
        
        while (attempts > 0) {
            setColor(CYAN);
            cout << "\n  Username: ";
            setColor(BRIGHT_WHITE);
            cin >> username;
            
            setColor(CYAN);
            cout << "  Password: ";
            setColor(BRIGHT_WHITE);
            cin >> password;
            setColor(WHITE);
            
            if (username == ADMIN_USER && password == ADMIN_PASS) {
                loadingAnimation("Verifying credentials", 1000);
                printSuccess("Login successful!");
                sleep(1500);
                return true;
            } else {
                attempts--;
                if (attempts > 0) {
                    setColor(BRIGHT_RED);
                    cout << "\n  Invalid credentials. Attempts left: " << attempts << endl;
                    setColor(WHITE);
                    sleep(1000);
                }
            }
        }
        
        printError("Maximum login attempts reached. Access denied!");
        sleep(2000);
        return false;
    }
    
    // Question bank management menu
    void questionBankMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("QUESTION BANK MANAGEMENT");
            
            setColor(BRIGHT_CYAN);
            cout << "\n  QUESTION BANK MENU\n";
            cout << "  =======================================================\n";
            setColor(WHITE);
            
            cout << "  [1]  Add New Question\n";
            cout << "  [2]  View All Questions\n";
            cout << "  [3]  Search Question by ID\n";
            cout << "  [4]  Delete Question\n";
            cout << "  [5]  Back to Main Menu\n";
            setColor(BRIGHT_CYAN);
            cout << "  =======================================================\n";
            cout << "  Select option [1-5]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE);
            
            switch (choice) {
                case 1: 
                    questionBank.addQuestion();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 2: 
                    questionBank.displayAllQuestions();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 3: {
                    int questionID;
                    cout << "\nEnter Question ID: ";
                    cin >> questionID;
                    Question* question = questionBank.searchQuestion(questionID);
                    if (question != NULL) {
                        question->displayQuestion();
                    } else {
                        printError("Question not found!");
                    }
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 4: {
                    int questionID;
                    cout << "\nEnter Question ID to delete: ";
                    cin >> questionID;
                    questionBank.deleteQuestion(questionID);
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 5: 
                    break;
                default:
                    printError("Invalid choice!");
                    sleep(2000);
            }
            
        } while (choice != 5);
    }
    
    // Student management menu
    void studentManagementMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("STUDENT MANAGEMENT");
            
            setColor(BRIGHT_MAGENTA);
            cout << "\n  STUDENT MENU\n";
            cout << "  =======================================================\n";
            setColor(WHITE);
            
            cout << "  [1]  Add New Student\n";
            cout << "  [2]  View All Students\n";
            cout << "  [3]  Search Student by ID\n";
            cout << "  [4]  Update Student Information\n";
            cout << "  [5]  Back to Main Menu\n";
            setColor(BRIGHT_MAGENTA);
            cout << "  =======================================================\n";
            cout << "  Select option [1-5]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE);
            
            switch (choice) {
                case 1: 
                    studentManager.addStudent();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 2: 
                    studentManager.displayAllStudents();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 3: {
                    int studentID;
                    cout << "\nEnter Student ID: ";
                    cin >> studentID;
                    Student* student = studentManager.searchStudent(studentID);
                    if (student != NULL) {
                        student->displayStudent();
                    } else {
                        printError("Student not found!");
                    }
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 4: {
                    int studentID;
                    cout << "\nEnter Student ID to update: ";
                    cin >> studentID;
                    studentManager.updateStudent(studentID);
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 5: 
                    break;
                default:
                    printError("Invalid choice!");
                    sleep(2000);
            }
            
        } while (choice != 5);
    }
    
    // Exam management menu
    void examManagementMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("EXAM MANAGEMENT");
            
            setColor(BRIGHT_YELLOW);
            cout << "\n  EXAM MENU\n";
            cout << "  =======================================================\n";
            setColor(WHITE);
            
            cout << "  [1]  Conduct Exam\n";
            cout << "  [2]  View All Results\n";
            cout << "  [3]  Search Result by Student ID\n";
            cout << "  [4]  Calculate Ranks for Subject\n";
            cout << "  [5]  Generate Merit List\n";
            cout << "  [6]  View Statistics\n";
            cout << "  [7]  Back to Main Menu\n";
            setColor(BRIGHT_YELLOW);
            cout << "  =======================================================\n";
            cout << "  Select option [1-7]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE);
            
            switch (choice) {
                case 1: {
                    int studentID;
                    char subject[50];
                    
                    cout << "\nEnter Student ID: ";
                    cin >> studentID;
                    
                    cin.ignore();
                    cout << "Enter Subject: ";
                    cin.getline(subject, 50);
                    
                    examManager->conductExam(studentID, subject);
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 2: 
                    examManager->displayAllResults();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 3: {
                    int studentID;
                    cout << "\nEnter Student ID: ";
                    cin >> studentID;
                    examManager->searchResultByStudent(studentID);
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 4: {
                    char subject[50];
                    cin.ignore();
                    cout << "\nEnter Subject: ";
                    cin.getline(subject, 50);
                    examManager->calculateRanks(subject);
                    cout << "\nPress Enter to continue...";
                    cin.get();
                    break;
                }
                case 5: {
                    char subject[50];
                    int topN;
                    
                    cin.ignore();
                    cout << "\nEnter Subject: ";
                    cin.getline(subject, 50);
                    
                    cout << "Enter number of top students to display: ";
                    cin >> topN;
                    
                    examManager->generateMeritList(subject, topN);
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 6: 
                    examManager->displayStatistics();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 7: 
                    break;
                default:
                    printError("Invalid choice!");
                    sleep(2000);
            }
            
        } while (choice != 7);
    }
    
    // Main menu
    void mainMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("ONLINE EXAMINATION SYSTEM");
            
            setColor(BRIGHT_YELLOW);
            cout << "\n  MAIN MENU\n";
            cout << "  =======================================================\n";
            setColor(WHITE);
            
            cout << "  [1]  Question Bank Management\n";
            cout << "  [2]  Student Management\n";
            cout << "  [3]  Exam Management\n";
            cout << "  [4]  Save All Data\n";
            cout << "  [5]  Exit System\n";
            setColor(BRIGHT_YELLOW);
            cout << "  =======================================================\n";
            cout << "  Select option [1-5]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE);
            
            switch (choice) {
                case 1: 
                    questionBankMenu();
                    break;
                case 2: 
                    studentManagementMenu();
                    break;
                case 3: 
                    examManagementMenu();
                    break;
                case 4: 
                    saveAllData();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 5: 
                    break;
                default:
                    printError("Invalid choice!");
                    sleep(2000);
            }
            
        } while (choice != 5);
    }
    
    // Save all data
    void saveAllData() {
        clearScreen();
        printHeader("SAVE EXAMINATION DATA");
        
        loadingAnimation("Saving all examination data", 1500);
        
        questionBank.saveToFile();
        studentManager.saveToFile();
        examManager->saveToFile();
        
        printSuccess("All examination data saved successfully!");
    }
    
    // Run system
    void run() {
        initialize();
        
        if (!adminLogin()) {
            return;
        }
        
        mainMenu();
        
        // Ask to save before exit
        clearScreen();
        printHeader("EXIT EXAMINATION SYSTEM");
        
        char save;
        setColor(BRIGHT_YELLOW);
        cout << "\n  Save data before exiting? (y/n): ";
        setColor(BRIGHT_WHITE);
        cin >> save;
        setColor(WHITE);
        
        if (save == 'y' || save == 'Y') {
            saveAllData();
        }
        
        clearScreen();
        setColor(BRIGHT_CYAN);
        cout << "\n============================================================\n";
        cout << "                   THANK YOU FOR USING\n";
        cout << "       ONLINE EXAMINATION & RESULT PROCESSING SYSTEM\n";
        cout << "                        Goodbye!\n";
        cout << "============================================================\n";
        setColor(WHITE);
        
        sleep(2000);
    }
};

// ====================== MAIN FUNCTION ======================
int main() {
    ExaminationSystem examSystem;
    examSystem.run();
    return 0;
}