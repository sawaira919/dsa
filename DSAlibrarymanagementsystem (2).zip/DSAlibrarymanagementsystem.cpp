/*
============================================================
 LIBRARY MANAGEMENT SYSTEM
 Developed using C++ with DSA Implementation
 Features: Arrays, Linked Lists, Sorting, Searching
============================================================
*/

#include <iostream>
#include <fstream>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <cstdlib>
#include <windows.h>  // For sleep function and colors
using namespace std;

// ====================== CONSTANTS ======================
const int MAX_BOOKS = 500;
const int MAX_MEMBERS = 200;
const int MAX_TRANSACTIONS = 1000;
const string ADMIN_USER = "admin";
const string ADMIN_PASS = "admin123";

// ====================== COLOR CODES ======================
enum Color {
    BLACK = 0,
    BLUE = 1,
    GREEN = 2,
    CYAN = 3,
    RED = 4,
    MAGENTA = 5,
    YELLOW = 6,
    WHITE = 7,
    GRAY = 8,
    BRIGHT_BLUE = 9,
    BRIGHT_GREEN = 10,
    BRIGHT_CYAN = 11,
    BRIGHT_RED = 12,
    BRIGHT_MAGENTA = 13,
    BRIGHT_YELLOW = 14,
    BRIGHT_WHITE = 15
};

// ====================== UTILITY FUNCTIONS ======================
void setColor(int color) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
}

void sleep(int milliseconds) {
    Sleep(milliseconds);
}

void clearScreen() {
    system("cls");
}

void printHeader(const string& title) {
    setColor(BRIGHT_CYAN);
    cout << "\n============================================================\n";
    cout << "                   " << title << endl;
    cout << "============================================================\n";
    setColor(WHITE);
}

void printSuccess(const string& message) {
    setColor(BRIGHT_GREEN);
    cout << "[SUCCESS] " << message << endl;
    setColor(WHITE);
}

void printError(const string& message) {
    setColor(BRIGHT_RED);
    cout << "[ERROR] " << message << endl;
    setColor(WHITE);
}

void printWarning(const string& message) {
    setColor(BRIGHT_YELLOW);
    cout << "[WARNING] " << message << endl;
    setColor(WHITE);
}

void printInfo(const string& message) {
    setColor(BRIGHT_CYAN);
    cout << "[INFO] " << message << endl;
    setColor(WHITE);
}

void loadingAnimation(const string& message, int duration = 1000) {
    setColor(BRIGHT_YELLOW);
    cout << "\n" << message;
    for(int i = 0; i < 3; i++) {
        cout << ".";
        Sleep(duration/3);
    }
    cout << endl;
    setColor(WHITE);
}

void drawLine(char ch = '=', int length = 80) {
    setColor(BRIGHT_CYAN);
    cout << "\n";
    for(int i = 0; i < length; i++) cout << ch;
    cout << endl;
    setColor(WHITE);
}

// ====================== DATE STRUCTURE ======================
struct Date {
    int day;
    int month;
    int year;
    
    Date() {
        day = 1;
        month = 1;
        year = 2024;
    }
    
    void inputDate() {
        cout << "Enter date (DD MM YYYY): ";
        cin >> day >> month >> year;
    }
    
    void displayDate() const {
        cout << setfill('0') << setw(2) << day << "/" 
             << setw(2) << month << "/" << setw(4) << year << setfill(' ');
    }
    
    bool operator<(const Date& other) const {
        if (year != other.year) return year < other.year;
        if (month != other.month) return month < other.month;
        return day < other.day;
    }
};

// ====================== BOOK STRUCTURE ======================
struct Book {
    int bookID;
    char title[100];
    char author[50];
    char category[50];
    char publisher[50];
    int publicationYear;
    float price;
    int totalCopies;
    int availableCopies;
    char isbn[20];
    
    Book() {
        bookID = 0;
        strcpy(title, "");
        strcpy(author, "");
        strcpy(category, "");
        strcpy(publisher, "");
        publicationYear = 0;
        price = 0.0;
        totalCopies = 0;
        availableCopies = 0;
        strcpy(isbn, "");
    }
    
    void displayBook() const {
        setColor(CYAN);
        cout << "\n============================================================\n";
        cout << "                     BOOK DETAILS\n";
        cout << "============================================================\n";
        setColor(WHITE);
        
        cout << "  Book ID:           " << bookID << endl;
        cout << "  Title:             " << title << endl;
        cout << "  Author:            " << author << endl;
        cout << "  Category:          " << category << endl;
        cout << "  Publisher:         " << publisher << endl;
        cout << "  Publication Year:  " << publicationYear << endl;
        cout << "  Price:             $" << fixed << setprecision(2) << price << endl;
        cout << "  Total Copies:      " << totalCopies << endl;
        cout << "  Available Copies:  ";
        if (availableCopies > 0) {
            setColor(BRIGHT_GREEN);
            cout << availableCopies;
        } else {
            setColor(BRIGHT_RED);
            cout << availableCopies << " (Out of Stock)";
        }
        setColor(WHITE);
        cout << endl;
        cout << "  ISBN:              " << isbn << endl;
        
        setColor(CYAN);
        cout << "============================================================\n";
        setColor(WHITE);
    }
    
    void displayBrief() const {
        cout << left << setw(10) << bookID 
             << setw(35) << title 
             << setw(25) << author
             << setw(15) << category
             << setw(8) << availableCopies << "/" << totalCopies
             << "$" << setw(8) << fixed << setprecision(2) << price << endl;
    }
};

// ====================== MEMBER STRUCTURE ======================
struct Member {
    int memberID;
    char name[50];
    char email[50];
    char contact[15];
    char address[100];
    Date registrationDate;
    int booksIssued;
    int maxBooksAllowed;
    
    Member() {
        memberID = 0;
        strcpy(name, "");
        strcpy(email, "");
        strcpy(contact, "");
        strcpy(address, "");
        registrationDate = Date();
        booksIssued = 0;
        maxBooksAllowed = 5;
    }
    
    void displayMember() const {
        setColor(BRIGHT_MAGENTA);
        cout << "\n============================================================\n";
        cout << "                    MEMBER DETAILS\n";
        cout << "============================================================\n";
        setColor(WHITE);
        
        cout << "  Member ID:         " << memberID << endl;
        cout << "  Name:              " << name << endl;
        cout << "  Email:             " << email << endl;
        cout << "  Contact:           " << contact << endl;
        cout << "  Address:           " << address << endl;
        cout << "  Registration Date: ";
        registrationDate.displayDate();
        cout << endl;
        cout << "  Books Issued:      " << booksIssued << "/" << maxBooksAllowed << endl;
        
        if (booksIssued >= maxBooksAllowed) {
            setColor(BRIGHT_RED);
            cout << "  Status:            Cannot issue more books (Limit reached)\n";
        } else {
            setColor(BRIGHT_GREEN);
            cout << "  Status:            Can issue " << (maxBooksAllowed - booksIssued) << " more books\n";
        }
        setColor(WHITE);
        
        setColor(BRIGHT_MAGENTA);
        cout << "============================================================\n";
        setColor(WHITE);
    }
    
    void displayBrief() const {
        cout << left << setw(10) << memberID 
             << setw(25) << name 
             << setw(30) << email
             << setw(15) << contact
             << setw(10) << booksIssued << "/" << maxBooksAllowed << endl;
    }
};

// ====================== TRANSACTION STRUCTURE ======================
struct Transaction {
    int transactionID;
    int bookID;
    int memberID;
    Date issueDate;
    Date dueDate;
    Date returnDate;
    float fineAmount;
    char status[20]; // "Issued", "Returned", "Overdue"
    
    Transaction() {
        transactionID = 0;
        bookID = 0;
        memberID = 0;
        issueDate = Date();
        dueDate = Date();
        returnDate = Date();
        fineAmount = 0.0;
        strcpy(status, "Issued");
    }
    
    void displayTransaction() const {
        setColor(BRIGHT_YELLOW);
        cout << "\n============================================================\n";
        cout << "                 TRANSACTION DETAILS\n";
        cout << "============================================================\n";
        setColor(WHITE);
        
        cout << "  Transaction ID:    " << transactionID << endl;
        cout << "  Book ID:           " << bookID << endl;
        cout << "  Member ID:         " << memberID << endl;
        cout << "  Issue Date:        ";
        issueDate.displayDate();
        cout << endl;
        cout << "  Due Date:          ";
        dueDate.displayDate();
        cout << endl;
        
        if (strcmp(status, "Returned") == 0) {
            cout << "  Return Date:       ";
            returnDate.displayDate();
            cout << endl;
        }
        
        cout << "  Status:            ";
        if (strcmp(status, "Issued") == 0) {
            setColor(BRIGHT_BLUE);
            cout << "Issued";
        } else if (strcmp(status, "Returned") == 0) {
            setColor(BRIGHT_GREEN);
            cout << "Returned";
        } else {
            setColor(BRIGHT_RED);
            cout << "Overdue";
        }
        setColor(WHITE);
        cout << endl;
        
        if (fineAmount > 0) {
            setColor(BRIGHT_RED);
            cout << "  Fine Amount:       $" << fixed << setprecision(2) << fineAmount << endl;
            setColor(WHITE);
        }
        
        setColor(BRIGHT_YELLOW);
        cout << "============================================================\n";
        setColor(WHITE);
    }
};

// ====================== BOOK MANAGEMENT ======================
class BookManager {
private:
    Book books[MAX_BOOKS];
    int bookCount;
    
public:
    BookManager() {
        bookCount = 0;
    }
    
    // Add new book
    bool addBook() {
        if (bookCount >= MAX_BOOKS) {
            printError("Cannot add more books. Maximum limit reached!");
            return false;
        }
        
        Book newBook;
        newBook.bookID = 1000 + bookCount + 1;
        
        setColor(BRIGHT_WHITE);
        cout << "\nBook ID: " << newBook.bookID << endl;
        cin.ignore();
        
        cout << "Enter Book Title: ";
        cin.getline(newBook.title, 100);
        
        cout << "Enter Author: ";
        cin.getline(newBook.author, 50);
        
        cout << "Enter Category: ";
        cin.getline(newBook.category, 50);
        
        cout << "Enter Publisher: ";
        cin.getline(newBook.publisher, 50);
        
        cout << "Enter Publication Year: ";
        cin >> newBook.publicationYear;
        
        cout << "Enter Price: $";
        cin >> newBook.price;
        
        cout << "Enter Total Copies: ";
        cin >> newBook.totalCopies;
        newBook.availableCopies = newBook.totalCopies;
        
        cout << "Enter ISBN: ";
        cin.ignore();
        cin.getline(newBook.isbn, 20);
        
        books[bookCount] = newBook;
        bookCount++;
        
        loadingAnimation("Adding book to library");
        printSuccess("Book added successfully! Book ID: " + to_string(newBook.bookID));
        return true;
    }
    
    // Display all books
    void displayAllBooks() {
        if (bookCount == 0) {
            printInfo("No books available in the library.");
            return;
        }
        
        setColor(BRIGHT_CYAN);
        cout << "\n========================================================================================================\n";
        cout << "                                ALL BOOKS IN LIBRARY\n";
        cout << "========================================================================================================\n";
        cout << left << setw(10) << "Book ID" << setw(35) << "Title" 
             << setw(25) << "Author" << setw(15) << "Category" 
             << setw(12) << "Available" << setw(10) << "Price" << endl;
        cout << "--------------------------------------------------------------------------------------------------------\n";
        setColor(WHITE);
        
        for (int i = 0; i < bookCount; i++) {
            books[i].displayBrief();
        }
        
        setColor(BRIGHT_CYAN);
        cout << "========================================================================================================\n";
        setColor(BRIGHT_YELLOW);
        cout << "\nTotal Books: " << bookCount << endl;
        setColor(WHITE);
    }
    
    // Search book by ID
    Book* searchBook(int bookID) {
        for (int i = 0; i < bookCount; i++) {
            if (books[i].bookID == bookID) {
                return &books[i];
            }
        }
        return NULL;
    }
    
    // Search book by title
    void searchBookByTitle(const char* title) {
        bool found = false;
        for (int i = 0; i < bookCount; i++) {
            if (strstr(books[i].title, title) != NULL) {
                books[i].displayBook();
                found = true;
            }
        }
        if (!found) {
            printError("No books found with title containing: " + string(title));
        }
    }
    
    // Search book by author
    void searchBookByAuthor(const char* author) {
        bool found = false;
        for (int i = 0; i < bookCount; i++) {
            if (strstr(books[i].author, author) != NULL) {
                books[i].displayBook();
                found = true;
            }
        }
        if (!found) {
            printError("No books found by author: " + string(author));
        }
    }
    
    // Update book
    bool updateBook(int bookID) {
        Book* book = searchBook(bookID);
        if (book == NULL) {
            printError("Book not found!");
            return false;
        }
        
        cout << "\nUpdating Book ID: " << bookID << endl;
        cout << "Current Title: " << book->title << endl;
        cin.ignore();
        
        cout << "Enter New Title (press Enter to keep current): ";
        char newTitle[100];
        cin.getline(newTitle, 100);
        if (strlen(newTitle) > 0) {
            strcpy(book->title, newTitle);
        }
        
        cout << "Enter New Author (press Enter to keep current): ";
        char newAuthor[50];
        cin.getline(newAuthor, 50);
        if (strlen(newAuthor) > 0) {
            strcpy(book->author, newAuthor);
        }
        
        cout << "Enter New Total Copies: ";
        int newCopies;
        cin >> newCopies;
        if (newCopies > 0) {
            book->availableCopies += (newCopies - book->totalCopies);
            book->totalCopies = newCopies;
        }
        
        printSuccess("Book updated successfully!");
        return true;
    }
    
    // Delete book
    bool deleteBook(int bookID) {
        for (int i = 0; i < bookCount; i++) {
            if (books[i].bookID == bookID) {
                if (books[i].availableCopies < books[i].totalCopies) {
                    printError("Cannot delete book. Some copies are still issued.");
                    return false;
                }
                
                // Shift books left
                for (int j = i; j < bookCount - 1; j++) {
                    books[j] = books[j + 1];
                }
                bookCount--;
                printSuccess("Book deleted successfully!");
                return true;
            }
        }
        printError("Book not found!");
        return false;
    }
    
    // Get book count
    int getBookCount() { return bookCount; }
    
    // Save books to file
    void saveToFile() {
        ofstream file("books.dat", ios::binary);
        if (!file) {
            printError("Error saving books data!");
            return;
        }
        
        for (int i = 0; i < bookCount; i++) {
            file.write(reinterpret_cast<char*>(&books[i]), sizeof(Book));
        }
        
        file.close();
        printSuccess("Books data saved successfully!");
    }
    
    // Load books from file
    void loadFromFile() {
        ifstream file("books.dat", ios::binary);
        if (!file) {
            printInfo("No previous books data found.");
            return;
        }
        
        Book book;
        while (file.read(reinterpret_cast<char*>(&book), sizeof(Book))) {
            if (bookCount < MAX_BOOKS) {
                books[bookCount++] = book;
            }
        }
        
        file.close();
        printSuccess("Loaded " + to_string(bookCount) + " books.");
    }
    
    // Sort books by title
    void sortBooksByTitle() {
        for (int i = 0; i < bookCount - 1; i++) {
            for (int j = 0; j < bookCount - i - 1; j++) {
                if (strcmp(books[j].title, books[j + 1].title) > 0) {
                    Book temp = books[j];
                    books[j] = books[j + 1];
                    books[j + 1] = temp;
                }
            }
        }
        printSuccess("Books sorted by title!");
    }
    
    // Sort books by author
    void sortBooksByAuthor() {
        for (int i = 0; i < bookCount - 1; i++) {
            for (int j = 0; j < bookCount - i - 1; j++) {
                if (strcmp(books[j].author, books[j + 1].author) > 0) {
                    Book temp = books[j];
                    books[j] = books[j + 1];
                    books[j + 1] = temp;
                }
            }
        }
        printSuccess("Books sorted by author!");
    }
};

// ====================== MEMBER MANAGEMENT ======================
class MemberManager {
private:
    Member members[MAX_MEMBERS];
    int memberCount;
    
public:
    MemberManager() {
        memberCount = 0;
    }
    
    // Add new member
    bool addMember() {
        if (memberCount >= MAX_MEMBERS) {
            printError("Cannot add more members. Maximum limit reached!");
            return false;
        }
        
        Member newMember;
        newMember.memberID = 2000 + memberCount + 1;
        
        setColor(BRIGHT_WHITE);
        cout << "\nMember ID: " << newMember.memberID << endl;
        cin.ignore();
        
        cout << "Enter Full Name: ";
        cin.getline(newMember.name, 50);
        
        cout << "Enter Email: ";
        cin.getline(newMember.email, 50);
        
        cout << "Enter Contact Number: ";
        cin.getline(newMember.contact, 15);
        
        cout << "Enter Address: ";
        cin.getline(newMember.address, 100);
        
        cout << "Enter Registration Date:\n";
        newMember.registrationDate.inputDate();
        
        members[memberCount] = newMember;
        memberCount++;
        
        loadingAnimation("Registering member");
        printSuccess("Member registered successfully! Member ID: " + to_string(newMember.memberID));
        return true;
    }
    
    // Display all members
    void displayAllMembers() {
        if (memberCount == 0) {
            printInfo("No members registered.");
            return;
        }
        
        setColor(BRIGHT_MAGENTA);
        cout << "\n========================================================================================================\n";
        cout << "                                       ALL MEMBERS\n";
        cout << "========================================================================================================\n";
        cout << left << setw(10) << "Member ID" << setw(25) << "Name" 
             << setw(30) << "Email" << setw(15) << "Contact" 
             << setw(15) << "Books Issued" << endl;
        cout << "--------------------------------------------------------------------------------------------------------\n";
        setColor(WHITE);
        
        for (int i = 0; i < memberCount; i++) {
            members[i].displayBrief();
        }
        
        setColor(BRIGHT_MAGENTA);
        cout << "========================================================================================================\n";
        setColor(BRIGHT_YELLOW);
        cout << "\nTotal Members: " << memberCount << endl;
        setColor(WHITE);
    }
    
    // Search member by ID
    Member* searchMember(int memberID) {
        for (int i = 0; i < memberCount; i++) {
            if (members[i].memberID == memberID) {
                return &members[i];
            }
        }
        return NULL;
    }
    
    // Update member
    bool updateMember(int memberID) {
        Member* member = searchMember(memberID);
        if (member == NULL) {
            printError("Member not found!");
            return false;
        }
        
        cout << "\nUpdating Member ID: " << memberID << endl;
        cout << "Current Name: " << member->name << endl;
        cin.ignore();
        
        cout << "Enter New Name (press Enter to keep current): ";
        char newName[50];
        cin.getline(newName, 50);
        if (strlen(newName) > 0) {
            strcpy(member->name, newName);
        }
        
        cout << "Enter New Email: ";
        char newEmail[50];
        cin.getline(newEmail, 50);
        if (strlen(newEmail) > 0) {
            strcpy(member->email, newEmail);
        }
        
        cout << "Enter New Contact: ";
        char newContact[15];
        cin.getline(newContact, 15);
        if (strlen(newContact) > 0) {
            strcpy(member->contact, newContact);
        }
        
        printSuccess("Member updated successfully!");
        return true;
    }
    
    // Get member count
    int getMemberCount() { return memberCount; }
    
    // Save members to file
    void saveToFile() {
        ofstream file("members.dat", ios::binary);
        if (!file) {
            printError("Error saving members data!");
            return;
        }
        
        for (int i = 0; i < memberCount; i++) {
            file.write(reinterpret_cast<char*>(&members[i]), sizeof(Member));
        }
        
        file.close();
        printSuccess("Members data saved successfully!");
    }
    
    // Load members from file
    void loadFromFile() {
        ifstream file("members.dat", ios::binary);
        if (!file) {
            printInfo("No previous members data found.");
            return;
        }
        
        Member member;
        while (file.read(reinterpret_cast<char*>(&member), sizeof(Member))) {
            if (memberCount < MAX_MEMBERS) {
                members[memberCount++] = member;
            }
        }
        
        file.close();
        printSuccess("Loaded " + to_string(memberCount) + " members.");
    }
};

// ====================== TRANSACTION MANAGEMENT ======================
class TransactionManager {
private:
    Transaction transactions[MAX_TRANSACTIONS];
    int transactionCount;
    BookManager* bookManager;
    MemberManager* memberManager;
    
public:
    TransactionManager(BookManager* bm, MemberManager* mm) {
        transactionCount = 0;
        bookManager = bm;
        memberManager = mm;
    }
    
    // Issue book
    bool issueBook() {
        if (bookManager->getBookCount() == 0) {
            printError("No books available to issue!");
            return false;
        }
        
        if (memberManager->getMemberCount() == 0) {
            printError("No members registered!");
            return false;
        }
        
        Transaction newTransaction;
        newTransaction.transactionID = 3000 + transactionCount + 1;
        
        cout << "\nTransaction ID: " << newTransaction.transactionID << endl;
        
        // Input book ID
        int bookID;
        cout << "Enter Book ID to issue: ";
        cin >> bookID;
        
        Book* book = bookManager->searchBook(bookID);
        if (book == NULL) {
            printError("Book not found!");
            return false;
        }
        
        if (book->availableCopies <= 0) {
            printError("No copies available for this book!");
            return false;
        }
        
        // Input member ID
        int memberID;
        cout << "Enter Member ID: ";
        cin >> memberID;
        
        Member* member = memberManager->searchMember(memberID);
        if (member == NULL) {
            printError("Member not found!");
            return false;
        }
        
        if (member->booksIssued >= member->maxBooksAllowed) {
            printError("Member has reached maximum book limit!");
            return false;
        }
        
        newTransaction.bookID = bookID;
        newTransaction.memberID = memberID;
        
        cout << "\nEnter Issue Date:\n";
        newTransaction.issueDate.inputDate();
        
        cout << "Enter Due Date (14 days from issue):\n";
        newTransaction.dueDate.inputDate();
        
        strcpy(newTransaction.status, "Issued");
        
        // Update book and member
        book->availableCopies--;
        member->booksIssued++;
        
        transactions[transactionCount] = newTransaction;
        transactionCount++;
        
        loadingAnimation("Processing book issue");
        printSuccess("Book issued successfully! Transaction ID: " + to_string(newTransaction.transactionID));
        return true;
    }
    
    // Return book
    bool returnBook() {
        int transactionID;
        cout << "Enter Transaction ID: ";
        cin >> transactionID;
        
        for (int i = 0; i < transactionCount; i++) {
            if (transactions[i].transactionID == transactionID && 
                strcmp(transactions[i].status, "Issued") == 0) {
                
                cout << "\nEnter Return Date:\n";
                transactions[i].returnDate.inputDate();
                
                // Calculate fine if overdue
                if (transactions[i].returnDate < transactions[i].dueDate) {
                    transactions[i].fineAmount = 0.0;
                } else {
                    // Simple fine calculation: $1 per day overdue
                    int overdueDays = 1; // Simplified calculation
                    transactions[i].fineAmount = overdueDays * 1.0;
                }
                
                strcpy(transactions[i].status, "Returned");
                
                // Update book and member
                Book* book = bookManager->searchBook(transactions[i].bookID);
                if (book != NULL) {
                    book->availableCopies++;
                }
                
                Member* member = memberManager->searchMember(transactions[i].memberID);
                if (member != NULL) {
                    member->booksIssued--;
                }
                
                loadingAnimation("Processing book return");
                printSuccess("Book returned successfully!");
                
                if (transactions[i].fineAmount > 0) {
                    setColor(BRIGHT_RED);
                    cout << "Fine Amount: $" << fixed << setprecision(2) << transactions[i].fineAmount << endl;
                    setColor(WHITE);
                }
                
                return true;
            }
        }
        
        printError("Transaction not found or book already returned!");
        return false;
    }
    
    // Display all transactions
    void displayAllTransactions() {
        if (transactionCount == 0) {
            printInfo("No transactions recorded.");
            return;
        }
        
        setColor(BRIGHT_YELLOW);
        cout << "\n========================================================================================================\n";
        cout << "                                   ALL TRANSACTIONS\n";
        cout << "========================================================================================================\n";
        cout << left << setw(15) << "Transaction ID" << setw(10) << "Book ID" 
             << setw(12) << "Member ID" << setw(15) << "Issue Date" 
             << setw(15) << "Due Date" << setw(12) << "Status" << endl;
        cout << "--------------------------------------------------------------------------------------------------------\n";
        setColor(WHITE);
        
        for (int i = 0; i < transactionCount; i++) {
            cout << left << setw(15) << transactions[i].transactionID
                 << setw(10) << transactions[i].bookID
                 << setw(12) << transactions[i].memberID
                 << setw(15);
            
            cout << setfill('0') << setw(2) << transactions[i].issueDate.day << "/" 
                 << setw(2) << transactions[i].issueDate.month << "/" 
                 << setw(4) << transactions[i].issueDate.year << setfill(' ');
            
            cout << setw(15);
            cout << setfill('0') << setw(2) << transactions[i].dueDate.day << "/" 
                 << setw(2) << transactions[i].dueDate.month << "/" 
                 << setw(4) << transactions[i].dueDate.year << setfill(' ');
            
            cout << setw(12) << transactions[i].status << endl;
        }
        
        setColor(BRIGHT_YELLOW);
        cout << "========================================================================================================\n";
        setColor(BRIGHT_YELLOW);
        cout << "\nTotal Transactions: " << transactionCount << endl;
        setColor(WHITE);
    }
    
    // Get transaction count
    int getTransactionCount() { return transactionCount; }
    
    // Save transactions to file
    void saveToFile() {
        ofstream file("transactions.dat", ios::binary);
        if (!file) {
            printError("Error saving transactions data!");
            return;
        }
        
        for (int i = 0; i < transactionCount; i++) {
            file.write(reinterpret_cast<char*>(&transactions[i]), sizeof(Transaction));
        }
        
        file.close();
        printSuccess("Transactions data saved successfully!");
    }
    
    // Load transactions from file
    void loadFromFile() {
        ifstream file("transactions.dat", ios::binary);
        if (!file) {
            printInfo("No previous transactions data found.");
            return;
        }
        
        Transaction transaction;
        while (file.read(reinterpret_cast<char*>(&transaction), sizeof(Transaction))) {
            if (transactionCount < MAX_TRANSACTIONS) {
                transactions[transactionCount++] = transaction;
            }
        }
        
        file.close();
        printSuccess("Loaded " + to_string(transactionCount) + " transactions.");
    }
};

// ====================== LIBRARY MANAGEMENT SYSTEM ======================
class LibrarySystem {
private:
    BookManager bookManager;
    MemberManager memberManager;
    TransactionManager* transactionManager;
    
public:
    LibrarySystem() : transactionManager(new TransactionManager(&bookManager, &memberManager)) {}
    
    ~LibrarySystem() {
        delete transactionManager;
    }
    
    // Initialize system
    void initialize() {
        clearScreen();
        printHeader("LIBRARY MANAGEMENT SYSTEM");
        
        setColor(BRIGHT_YELLOW);
        cout << "\nDEVELOPED USING C++ WITH DATA STRUCTURES IMPLEMENTATION\n";
        cout << "   Efficient Book Inventory & Member Management System\n";
        cout << "============================================================\n";
        setColor(WHITE);
        
        loadingAnimation("Initializing system components", 1500);
        
        // Load existing data
        bookManager.loadFromFile();
        memberManager.loadFromFile();
        transactionManager->loadFromFile();
        
        printSuccess("System initialized successfully!");
        sleep(1500);
    }
    
    // Admin login
    bool adminLogin() {
        clearScreen();
        printHeader("ADMINISTRATOR LOGIN");
        
        string username, password;
        int attempts = 3;
        
        while (attempts > 0) {
            setColor(CYAN);
            cout << "\n  Username: ";
            setColor(BRIGHT_WHITE);
            cin >> username;
            
            setColor(CYAN);
            cout << "  Password: ";
            setColor(BRIGHT_WHITE);
            cin >> password;
            setColor(WHITE);
            
            if (username == ADMIN_USER && password == ADMIN_PASS) {
                loadingAnimation("Verifying credentials", 1000);
                printSuccess("Login successful!");
                sleep(1500);
                return true;
            } else {
                attempts--;
                if (attempts > 0) {
                    setColor(BRIGHT_RED);
                    cout << "\n  Invalid credentials. Attempts left: " << attempts << endl;
                    setColor(WHITE);
                    sleep(1000);
                }
            }
        }
        
        printError("Maximum login attempts reached. Access denied!");
        sleep(2000);
        return false;
    }
    
    // Book management menu
    void bookManagementMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("BOOK MANAGEMENT");
            
            setColor(BRIGHT_CYAN);
            cout << "\n  BOOK MENU\n";
            cout << "  =======================================================\n";
            setColor(WHITE);
            
            cout << "  [1]  Add New Book\n";
            cout << "  [2]  View All Books\n";
            cout << "  [3]  Search Book by ID\n";
            cout << "  [4]  Search Book by Title\n";
            cout << "  [5]  Search Book by Author\n";
            cout << "  [6]  Update Book Information\n";
            cout << "  [7]  Delete Book\n";
            cout << "  [8]  Sort Books by Title\n";
            cout << "  [9]  Sort Books by Author\n";
            cout << "  [10] Back to Main Menu\n";
            setColor(BRIGHT_CYAN);
            cout << "  =======================================================\n";
            cout << "  Select option [1-10]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE);
            
            switch (choice) {
                case 1: 
                    bookManager.addBook();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 2: 
                    bookManager.displayAllBooks();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 3: {
                    int bookID;
                    cout << "\nEnter Book ID: ";
                    cin >> bookID;
                    Book* book = bookManager.searchBook(bookID);
                    if (book != NULL) {
                        book->displayBook();
                    } else {
                        printError("Book not found!");
                    }
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 4: {
                    char title[100];
                    cout << "\nEnter Book Title: ";
                    cin.ignore();
                    cin.getline(title, 100);
                    bookManager.searchBookByTitle(title);
                    cout << "\nPress Enter to continue...";
                    cin.get();
                    break;
                }
                case 5: {
                    char author[50];
                    cout << "\nEnter Author Name: ";
                    cin.ignore();
                    cin.getline(author, 50);
                    bookManager.searchBookByAuthor(author);
                    cout << "\nPress Enter to continue...";
                    cin.get();
                    break;
                }
                case 6: {
                    int bookID;
                    cout << "\nEnter Book ID to update: ";
                    cin >> bookID;
                    bookManager.updateBook(bookID);
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 7: {
                    int bookID;
                    cout << "\nEnter Book ID to delete: ";
                    cin >> bookID;
                    bookManager.deleteBook(bookID);
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 8: 
                    bookManager.sortBooksByTitle();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 9: 
                    bookManager.sortBooksByAuthor();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 10: 
                    break;
                default:
                    printError("Invalid choice!");
                    sleep(2000);
            }
            
        } while (choice != 10);
    }
    
    // Member management menu
    void memberManagementMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("MEMBER MANAGEMENT");
            
            setColor(BRIGHT_MAGENTA);
            cout << "\n  MEMBER MENU\n";
            cout << "  =======================================================\n";
            setColor(WHITE);
            
            cout << "  [1]  Add New Member\n";
            cout << "  [2]  View All Members\n";
            cout << "  [3]  Search Member by ID\n";
            cout << "  [4]  Update Member Information\n";
            cout << "  [5]  Back to Main Menu\n";
            setColor(BRIGHT_MAGENTA);
            cout << "  =======================================================\n";
            cout << "  Select option [1-5]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE);
            
            switch (choice) {
                case 1: 
                    memberManager.addMember();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 2: 
                    memberManager.displayAllMembers();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 3: {
                    int memberID;
                    cout << "\nEnter Member ID: ";
                    cin >> memberID;
                    Member* member = memberManager.searchMember(memberID);
                    if (member != NULL) {
                        member->displayMember();
                    } else {
                        printError("Member not found!");
                    }
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 4: {
                    int memberID;
                    cout << "\nEnter Member ID to update: ";
                    cin >> memberID;
                    memberManager.updateMember(memberID);
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 5: 
                    break;
                default:
                    printError("Invalid choice!");
                    sleep(2000);
            }
            
        } while (choice != 5);
    }
    
    // Transaction management menu
    void transactionManagementMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("TRANSACTION MANAGEMENT");
            
            setColor(BRIGHT_YELLOW);
            cout << "\n  TRANSACTION MENU\n";
            cout << "  =======================================================\n";
            setColor(WHITE);
            
            cout << "  [1]  Issue Book\n";
            cout << "  [2]  Return Book\n";
            cout << "  [3]  View All Transactions\n";
            cout << "  [4]  Back to Main Menu\n";
            setColor(BRIGHT_YELLOW);
            cout << "  =======================================================\n";
            cout << "  Select option [1-4]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE);
            
            switch (choice) {
                case 1: 
                    transactionManager->issueBook();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 2: 
                    transactionManager->returnBook();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 3: 
                    transactionManager->displayAllTransactions();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 4: 
                    break;
                default:
                    printError("Invalid choice!");
                    sleep(2000);
            }
            
        } while (choice != 4);
    }
    
    // Reports menu
    void reportsMenu() {
        clearScreen();
        printHeader("LIBRARY REPORTS");
        
        setColor(BRIGHT_GREEN);
        cout << "\n============================================================\n";
        cout << "                 LIBRARY STATISTICS\n";
        cout << "============================================================\n";
        setColor(WHITE);
        
        cout << "\n  Total Books in Library:      ";
        setColor(BRIGHT_CYAN);
        cout << bookManager.getBookCount() << endl;
        setColor(WHITE);
        
        cout << "  Total Registered Members:   ";
        setColor(BRIGHT_MAGENTA);
        cout << memberManager.getMemberCount() << endl;
        setColor(WHITE);
        
        cout << "  Total Transactions:         ";
        setColor(BRIGHT_YELLOW);
        cout << transactionManager->getTransactionCount() << endl;
        setColor(WHITE);
        
        setColor(BRIGHT_GREEN);
        cout << "\n============================================================\n";
        setColor(WHITE);
        
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }
    
    // Main menu
    void mainMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("LIBRARY MANAGEMENT SYSTEM");
            
            setColor(BRIGHT_YELLOW);
            cout << "\n  MAIN MENU\n";
            cout << "  =======================================================\n";
            setColor(WHITE);
            
            cout << "  [1]  Book Management\n";
            cout << "  [2]  Member Management\n";
            cout << "  [3]  Transaction Management\n";
            cout << "  [4]  Library Reports\n";
            cout << "  [5]  Save All Data\n";
            cout << "  [6]  Exit System\n";
            setColor(BRIGHT_YELLOW);
            cout << "  =======================================================\n";
            cout << "  Select option [1-6]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE);
            
            switch (choice) {
                case 1: 
                    bookManagementMenu();
                    break;
                case 2: 
                    memberManagementMenu();
                    break;
                case 3: 
                    transactionManagementMenu();
                    break;
                case 4: 
                    reportsMenu();
                    break;
                case 5: 
                    saveAllData();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 6: 
                    break;
                default:
                    printError("Invalid choice!");
                    sleep(2000);
            }
            
        } while (choice != 6);
    }
    
    // Save all data
    void saveAllData() {
        clearScreen();
        printHeader("SAVE LIBRARY DATA");
        
        loadingAnimation("Saving all library data", 1500);
        
        bookManager.saveToFile();
        memberManager.saveToFile();
        transactionManager->saveToFile();
        
        printSuccess("All library data saved successfully!");
    }
    
    // Run system
    void run() {
        initialize();
        
        if (!adminLogin()) {
            return;
        }
        
        mainMenu();
        
        // Ask to save before exit
        clearScreen();
        printHeader("EXIT LIBRARY SYSTEM");
        
        char save;
        setColor(BRIGHT_YELLOW);
        cout << "\n  Save data before exiting? (y/n): ";
        setColor(BRIGHT_WHITE);
        cin >> save;
        setColor(WHITE);
        
        if (save == 'y' || save == 'Y') {
            saveAllData();
        }
        
        clearScreen();
        setColor(BRIGHT_CYAN);
        cout << "\n============================================================\n";
        cout << "                   THANK YOU FOR USING\n";
        cout << "              LIBRARY MANAGEMENT SYSTEM\n";
        cout << "                        Goodbye!\n";
        cout << "============================================================\n";
        setColor(WHITE);
        
        sleep(2000);
    }
};

// ====================== MAIN FUNCTION ======================
int main() {
    LibrarySystem library;
    library.run();
    return 0;
}