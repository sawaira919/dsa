/*
============================================================
 ONLINE VOTING SYSTEM WITH TIMER
 Developed using C++ with DSA Implementation
 Features: Voter Registration, Candidate Management, 
           Real-time Voting with Timer, Result Processing
============================================================
*/

#include <iostream>
#include <fstream>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <cstdlib>
#include <vector>
#include <algorithm>
#include <windows.h>
#include <cctype>
#include <string>
#include <chrono>
#include <thread>
#include <conio.h>
using namespace std;

// ====================== CONSTANTS ======================
const int MAX_VOTERS = 1000;
const int MAX_CANDIDATES = 50;
const int MAX_VOTES = 10000;
const string ADMIN_USER = "admin";
const string ADMIN_PASS = "admin123";
const int VOTING_TIME_MINUTES = 5; // Voting duration in minutes
const int PHONE_LENGTH = 10;

// ====================== COLOR CODES ======================
enum Color {
    BLACK = 0,
    BLUE = 1,
    GREEN = 2,
    CYAN = 3,
    RED = 4,
    MAGENTA = 5,
    YELLOW = 6,
    WHITE_COLOR = 7,  // Renamed from WHITE to avoid conflict
    GRAY = 8,
    BRIGHT_BLUE = 9,
    BRIGHT_GREEN = 10,
    BRIGHT_CYAN = 11,
    BRIGHT_RED = 12,
    BRIGHT_MAGENTA = 13,
    BRIGHT_YELLOW = 14,
    BRIGHT_WHITE = 15
};

// ====================== UTILITY FUNCTIONS ======================
void setColor(int color) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
}

void sleep(int milliseconds) {
    Sleep(milliseconds);
}

void clearScreen() {
    system("cls");
}

void printHeader(const string& title) {
    setColor(BRIGHT_CYAN);
    cout << "\n============================================================\n";
    cout << "                   " << title << endl;
    cout << "============================================================\n";
    setColor(WHITE_COLOR);
}

void printSuccess(const string& message) {
    setColor(BRIGHT_GREEN);
    cout << "[SUCCESS] " << message << endl;
    setColor(WHITE_COLOR);
}

void printError(const string& message) {
    setColor(BRIGHT_RED);
    cout << "[ERROR] " << message << endl;
    setColor(WHITE_COLOR);
}

void printWarning(const string& message) {
    setColor(BRIGHT_YELLOW);
    cout << "[WARNING] " << message << endl;
    setColor(WHITE_COLOR);
}

void printInfo(const string& message) {
    setColor(BRIGHT_CYAN);
    cout << "[INFO] " << message << endl;
    setColor(WHITE_COLOR);
}

void loadingAnimation(const string& message, int duration = 1000) {
    setColor(BRIGHT_YELLOW);
    cout << "\n" << message;
    for(int i = 0; i < 3; i++) {
        cout << ".";
        Sleep(duration/3);
    }
    cout << endl;
    setColor(WHITE_COLOR);
}

void drawBox(const string& text, int width = 60) {
    setColor(BRIGHT_CYAN);
    cout << "\n";
    for(int i = 0; i < width; i++) cout << "=";
    cout << "\n";
    
    cout << " " << left << setw(width - 2) << text << " \n";
    
    for(int i = 0; i < width; i++) cout << "=";
    cout << "\n";
    setColor(WHITE_COLOR);
}

// ====================== INPUT VALIDATION FUNCTIONS ======================
bool isValidEmail(const string& email) {
    size_t at_pos = email.find('@');
    size_t dot_pos = email.find('.', at_pos);
    return (at_pos != string::npos && dot_pos != string::npos && 
            dot_pos > at_pos + 1 && dot_pos < email.length() - 1);
}

bool isValidPhone(const string& phone) {
    if (phone.length() != PHONE_LENGTH) return false;
    for (char c : phone) {
        if (!isdigit(c)) return false;
    }
    return true;
}

bool isInteger(const string& str) {
    if (str.empty()) return false;
    for (char c : str) {
        if (!isdigit(c)) return false;
    }
    return true;
}

bool isValidAge(int age) {
    return (age >= 18 && age <= 120);
}

bool isValidCNIC(const string& cnic) {
    return (cnic.length() == 13 && isInteger(cnic));
}

// ====================== DATE STRUCTURE ======================
struct Date {
    int day, month, year;
    
    Date() { day = 1; month = 1; year = 2024; }
    
    Date(int d, int m, int y) { day = d; month = m; year = y; }
    
    void inputDate() {
        cout << "Enter date (DD MM YYYY): ";
        cin >> day >> month >> year;
    }
    
    void displayDate() const {
        cout << setfill('0') << setw(2) << day << "/" 
             << setw(2) << month << "/" << setw(4) << year;
    }
    
    bool operator<(const Date& other) const {
        if (year != other.year) return year < other.year;
        if (month != other.month) return month < other.month;
        return day < other.day;
    }
};

// ====================== VOTER STRUCTURE ======================
struct Voter {
    int voterID;
    char name[50];
    char cnic[15];
    char email[50];
    char contact[15];
    char address[100];
    Date dob;
    int age;
    char gender[10];
    bool hasVoted;
    char constituency[50];
    
    Voter() {
        voterID = 0;
        strcpy(name, "");
        strcpy(cnic, "");
        strcpy(email, "");
        strcpy(contact, "");
        strcpy(address, "");
        dob = Date();
        age = 0;
        strcpy(gender, "");
        hasVoted = false;
        strcpy(constituency, "");
    }
    
    void displayVoter() const {
        setColor(BRIGHT_MAGENTA);
        cout << "\n============================================================\n";
        cout << "                    VOTER DETAILS\n";
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
        
        cout << "  Voter ID:        " << voterID << endl;
        cout << "  Name:            " << name << endl;
        cout << "  CNIC:            " << cnic << endl;
        cout << "  Email:           " << email << endl;
        cout << "  Contact:         " << contact << endl;
        cout << "  Address:         " << address << endl;
        cout << "  Date of Birth:   ";
        dob.displayDate();
        cout << endl;
        cout << "  Age:             " << age << " years" << endl;
        cout << "  Gender:          " << gender << endl;
        cout << "  Constituency:    " << constituency << endl;
        cout << "  Voting Status:   ";
        if (hasVoted) {
            setColor(BRIGHT_GREEN);
            cout << "Already Voted";
        } else {
            setColor(BRIGHT_YELLOW);
            cout << "Not Voted Yet";
        }
        setColor(WHITE_COLOR);
        cout << endl;
        
        setColor(BRIGHT_MAGENTA);
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
    }
    
    void displayBrief() const {
        cout << left << setw(10) << voterID 
             << setw(25) << name 
             << setw(15) << cnic
             << setw(20) << constituency
             << setw(12) << age
             << setw(15);
        
        if (hasVoted) {
            setColor(BRIGHT_GREEN);
            cout << "Voted";
        } else {
            setColor(BRIGHT_YELLOW);
            cout << "Not Voted";
        }
        setColor(WHITE_COLOR);
        cout << endl;
    }
};

// ====================== CANDIDATE STRUCTURE ======================
struct Candidate {
    int candidateID;
    char name[50];
    char party[50];
    char symbol[20];
    char constituency[50];
    int votesReceived;
    char manifesto[500];
    char qualifications[200];
    int age;
    char gender[10];
    
    Candidate() {
        candidateID = 0;
        strcpy(name, "");
        strcpy(party, "");
        strcpy(symbol, "");
        strcpy(constituency, "");
        votesReceived = 0;
        strcpy(manifesto, "");
        strcpy(qualifications, "");
        age = 0;
        strcpy(gender, "");
    }
    
    void displayCandidate() const {
        setColor(BRIGHT_CYAN);
        cout << "\n============================================================\n";
        cout << "                    CANDIDATE DETAILS\n";
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
        
        cout << "  Candidate ID:    " << candidateID << endl;
        cout << "  Name:            " << name << endl;
        cout << "  Party:           " << party << endl;
        cout << "  Symbol:          " << symbol << endl;
        cout << "  Constituency:    " << constituency << endl;
        cout << "  Votes Received:  ";
        setColor(BRIGHT_YELLOW);
        cout << votesReceived << endl;
        setColor(WHITE_COLOR);
        cout << "  Age:             " << age << " years" << endl;
        cout << "  Gender:          " << gender << endl;
        cout << "  Qualifications:  " << qualifications << endl;
        cout << "  Manifesto:       " << manifesto << endl;
        
        setColor(BRIGHT_CYAN);
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
    }
    
    void displayBrief(bool showVotes = true) const {
        cout << left << setw(12) << candidateID 
             << setw(25) << name 
             << setw(20) << party
             << setw(15) << symbol
             << setw(20) << constituency;
        
        if (showVotes) {
            setColor(BRIGHT_YELLOW);
            cout << setw(10) << votesReceived;
            setColor(WHITE_COLOR);
        }
        cout << endl;
    }
};

// ====================== VOTE STRUCTURE ======================
struct Vote {
    int voteID;
    int voterID;
    int candidateID;
    Date voteDate;
    char voteTime[10];
    char constituency[50];
    
    Vote() {
        voteID = 0;
        voterID = 0;
        candidateID = 0;
        voteDate = Date();
        strcpy(voteTime, "");
        strcpy(constituency, "");
    }
    
    void displayVote() const {
        setColor(BRIGHT_YELLOW);
        cout << "\n============================================================\n";
        cout << "                      VOTE DETAILS\n";
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
        
        cout << "  Vote ID:         " << voteID << endl;
        cout << "  Voter ID:        " << voterID << endl;
        cout << "  Candidate ID:    " << candidateID << endl;
        cout << "  Vote Date:       ";
        voteDate.displayDate();
        cout << endl;
        cout << "  Vote Time:       " << voteTime << endl;
        cout << "  Constituency:    " << constituency << endl;
        
        setColor(BRIGHT_YELLOW);
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
    }
};

// ====================== TIMER CLASS ======================
class VotingTimer {
private:
    int minutes;
    int seconds;
    time_t startTime;
    bool isRunning;
    
public:
    VotingTimer(int mins = VOTING_TIME_MINUTES) {
        minutes = mins;
        seconds = 0;
        isRunning = false;
    }
    
    void start() {
        startTime = time(0);
        isRunning = true;
    }
    
    void stop() {
        isRunning = false;
    }
    
    bool isTimeUp() {
        if (!isRunning) return false;
        
        time_t currentTime = time(0);
        int elapsedSeconds = difftime(currentTime, startTime);
        int totalSeconds = minutes * 60 + seconds;
        
        return elapsedSeconds >= totalSeconds;
    }
    
    int getRemainingTime() {
        if (!isRunning) return 0;
        
        time_t currentTime = time(0);
        int elapsedSeconds = difftime(currentTime, startTime);
        int totalSeconds = minutes * 60 + seconds;
        int remaining = totalSeconds - elapsedSeconds;
        
        return (remaining > 0) ? remaining : 0;
    }
    
    void displayTimer() {
        if (!isRunning) {
            cout << "Timer not started" << endl;
            return;
        }
        
        int remaining = getRemainingTime();
        int mins = remaining / 60;
        int secs = remaining % 60;
        
        setColor(BRIGHT_CYAN);
        cout << "\nTIME REMAINING: ";
        if (remaining <= 60) {
            setColor(BRIGHT_RED);
        } else if (remaining <= 180) {
            setColor(BRIGHT_YELLOW);
        } else {
            setColor(BRIGHT_GREEN);
        }
        
        cout << setfill('0') << setw(2) << mins << ":" 
             << setw(2) << secs << setfill(' ') << endl;
        setColor(WHITE_COLOR);
    }
    
    bool checkTime() {
        if (isTimeUp()) {
            setColor(BRIGHT_RED);
            cout << "\nTIME'S UP! Voting session has ended.\n";
            setColor(WHITE_COLOR);
            return true;
        }
        return false;
    }
};

// ====================== VOTER MANAGEMENT ======================
class VoterManager {
private:
    Voter voters[MAX_VOTERS];
    int voterCount;
    
    void addDefaultVoter(int id, const char* name, const char* cnic, const char* email,
                        const char* contact, const char* addr, Date dob, 
                        const char* gender, const char* constituency) {
        if (voterCount >= MAX_VOTERS) return;
        
        Voter v;
        v.voterID = id;
        strcpy(v.name, name);
        strcpy(v.cnic, cnic);
        strcpy(v.email, email);
        strcpy(v.contact, contact);
        strcpy(v.address, addr);
        v.dob = dob;
        
        time_t now = time(0);
        tm* ltm = localtime(&now);
        v.age = (1900 + ltm->tm_year) - dob.year;
        
        strcpy(v.gender, gender);
        strcpy(v.constituency, constituency);
        v.hasVoted = false;
        
        voters[voterCount++] = v;
    }
    
public:
    VoterManager() {
        voterCount = 0;
    }
    
    // Add new voter with validation
    bool addVoter() {
        if (voterCount >= MAX_VOTERS) {
            printError("Cannot add more voters. Maximum limit reached!");
            return false;
        }
        
        Voter newVoter;
        newVoter.voterID = 1000 + voterCount + 1;
        
        setColor(BRIGHT_WHITE);
        cout << "\nVoter ID: " << newVoter.voterID << endl;
        cin.ignore();
        
        // Name input
        cout << "Enter Full Name: ";
        cin.getline(newVoter.name, 50);
        
        // CNIC input with validation
        string cnicInput;
        while (true) {
            cout << "Enter CNIC (13 digits without dashes): ";
            cin.getline(newVoter.cnic, 15);
            cnicInput = newVoter.cnic;
            
            if (isValidCNIC(cnicInput)) {
                // Check if CNIC already exists
                bool exists = false;
                for (int i = 0; i < voterCount; i++) {
                    if (strcmp(voters[i].cnic, newVoter.cnic) == 0) {
                        exists = true;
                        break;
                    }
                }
                
                if (!exists) {
                    break;
                } else {
                    printError("CNIC already registered!");
                }
            } else {
                printError("Invalid CNIC! Must be 13 digits.");
            }
        }
        
        // Email input with validation
        string emailInput;
        while (true) {
            cout << "Enter Email: ";
            cin.getline(newVoter.email, 50);
            emailInput = newVoter.email;
            
            if (isValidEmail(emailInput)) {
                break;
            } else {
                printError("Invalid email format! Please enter a valid email.");
            }
        }
        
        // Phone input with validation
        string phoneInput;
        while (true) {
            cout << "Enter Contact Number (" << PHONE_LENGTH << " digits): ";
            cin.getline(newVoter.contact, 15);
            phoneInput = newVoter.contact;
            
            if (isValidPhone(phoneInput)) {
                break;
            } else {
                printError("Invalid phone number! Must be " + to_string(PHONE_LENGTH) + " digits.");
            }
        }
        
        cout << "Enter Address: ";
        cin.getline(newVoter.address, 100);
        
        // Date of Birth input
        cout << "Enter Date of Birth:\n";
        newVoter.dob.inputDate();
        
        // Age calculation and validation
        time_t now = time(0);
        tm* ltm = localtime(&now);
        int currentYear = 1900 + ltm->tm_year;
        
        newVoter.age = currentYear - newVoter.dob.year;
        
        while (!isValidAge(newVoter.age)) {
            printError("Invalid age! Voter must be at least 18 years old.");
            cout << "Enter Date of Birth again:\n";
            newVoter.dob.inputDate();
            newVoter.age = currentYear - newVoter.dob.year;
        }
        
        // Gender input
        cout << "Enter Gender (Male/Female/Other): ";
        cin.getline(newVoter.gender, 10);
        
        cout << "Enter Constituency: ";
        cin.getline(newVoter.constituency, 50);
        
        newVoter.hasVoted = false;
        
        voters[voterCount] = newVoter;
        voterCount++;
        
        loadingAnimation("Registering voter");
        printSuccess("Voter registered successfully! Voter ID: " + to_string(newVoter.voterID));
        return true;
    }
    
    // Display all voters
    void displayAllVoters() {
        if (voterCount == 0) {
            printInfo("No voters registered.");
            return;
        }
        
        setColor(BRIGHT_MAGENTA);
        cout << "\n========================================================================================================\n";
        cout << "                                 ALL REGISTERED VOTERS\n";
        cout << "========================================================================================================\n";
        cout << left << setw(10) << "Voter ID" << setw(25) << "Name" 
             << setw(15) << "CNIC" << setw(20) << "Constituency" 
             << setw(12) << "Age" << setw(15) << "Voting Status" << endl;
        cout << "--------------------------------------------------------------------------------------------------------\n";
        setColor(WHITE_COLOR);
        
        for (int i = 0; i < voterCount; i++) {
            voters[i].displayBrief();
        }
        
        setColor(BRIGHT_MAGENTA);
        cout << "========================================================================================================\n";
        setColor(BRIGHT_YELLOW);
        cout << "\nTotal Voters: " << voterCount << endl;
        setColor(WHITE_COLOR);
    }
    
    // Search voter by ID
    Voter* searchVoter(int voterID) {
        for (int i = 0; i < voterCount; i++) {
            if (voters[i].voterID == voterID) {
                return &voters[i];
            }
        }
        return NULL;
    }
    
    // Search voter by CNIC
    Voter* searchVoterByCNIC(const char* cnic) {
        for (int i = 0; i < voterCount; i++) {
            if (strcmp(voters[i].cnic, cnic) == 0) {
                return &voters[i];
            }
        }
        return NULL;
    }
    
    // Mark voter as voted
    bool markVoted(int voterID) {
        Voter* voter = searchVoter(voterID);
        if (voter == NULL) {
            return false;
        }
        
        if (voter->hasVoted) {
            printError("This voter has already cast their vote!");
            return false;
        }
        
        voter->hasVoted = true;
        return true;
    }
    
    // Get voter count
    int getVoterCount() { return voterCount; }
    
    // Get voters by constituency
    vector<Voter*> getVotersByConstituency(const char* constituency) {
        vector<Voter*> constituencyVoters;
        for (int i = 0; i < voterCount; i++) {
            if (strcmp(voters[i].constituency, constituency) == 0) {
                constituencyVoters.push_back(&voters[i]);
            }
        }
        return constituencyVoters;
    }
    
    // Save voters to file
    void saveToFile() {
        ofstream file("voters.dat", ios::binary);
        if (!file) {
            printError("Error saving voters data!");
            return;
        }
        
        for (int i = 0; i < voterCount; i++) {
            file.write(reinterpret_cast<char*>(&voters[i]), sizeof(Voter));
        }
        
        file.close();
        printSuccess("Voters data saved successfully!");
    }
    
    // Load voters from file
    void loadFromFile() {
        ifstream file("voters.dat", ios::binary);
        if (!file) {
            printInfo("No previous voters data found.");
            addDefaultVoters();
            return;
        }
        
        Voter voter;
        while (file.read(reinterpret_cast<char*>(&voter), sizeof(Voter))) {
            if (voterCount < MAX_VOTERS) {
                voters[voterCount++] = voter;
            }
        }
        
        file.close();
        printSuccess("Loaded " + to_string(voterCount) + " voters.");
    }
    
    // Add default voters
    void addDefaultVoters() {
        addDefaultVoter(1001, "Ahmed Khan", "3520112345678", "ahmed.khan@email.com", "03001234567",
            "House 123, Street 45, Lahore", Date(15, 5, 1985), "Male", "NA-125");
        addDefaultVoter(1002, "Ayesha Bibi", "3520123456789", "ayesha.bibi@email.com", "03111234567",
            "House 490, Street 78, Karachi", Date(22, 6, 1990), "Female", "NA-250");
        addDefaultVoter(1003, "Usman Malik", "3520134567890", "usman.malik@email.com", "03221234567",
            "House 789, Street 12, Islamabad", Date(10, 3, 1988), "Male", "NA-54");
        addDefaultVoter(1004, "Sara Ahmed", "3520145678901", "sara.ahmed@email.com", "03331234567",
            "House 321, Street 65, Lahore", Date(5, 12, 1995), "Female", "NA-125");
        addDefaultVoter(1005, "Bilal Raza", "3520156789012", "bilal.raza@email.com", "03441234567",
            "House 654, Street 87, Karachi", Date(18, 7, 1980), "Male", "NA-250");
        printSuccess("Added " + to_string(voterCount) + " default voters.");
    }
};

// ====================== CANDIDATE MANAGEMENT ======================
class CandidateManager {
private:
    Candidate candidates[MAX_CANDIDATES];
    int candidateCount;
    
public:
    CandidateManager() {
        candidateCount = 0;
    }
    
    // Add new candidate
    bool addCandidate() {
        if (candidateCount >= MAX_CANDIDATES) {
            printError("Cannot add more candidates. Maximum limit reached!");
            return false;
        }
        
        Candidate newCandidate;
        newCandidate.candidateID = 2000 + candidateCount + 1;
        
        setColor(BRIGHT_WHITE);
        cout << "\nCandidate ID: " << newCandidate.candidateID << endl;
        cin.ignore();
        
        cout << "Enter Full Name: ";
        cin.getline(newCandidate.name, 50);
        
        cout << "Enter Political Party: ";
        cin.getline(newCandidate.party, 50);
        
        cout << "Enter Election Symbol: ";
        cin.getline(newCandidate.symbol, 20);
        
        cout << "Enter Constituency: ";
        cin.getline(newCandidate.constituency, 50);
        
        cout << "Enter Age: ";
        cin >> newCandidate.age;
        cin.ignore();
        
        cout << "Enter Gender (Male/Female/Other): ";
        cin.getline(newCandidate.gender, 10);
        
        cout << "Enter Qualifications: ";
        cin.getline(newCandidate.qualifications, 200);
        
        cout << "Enter Manifesto (key promises): ";
        cin.getline(newCandidate.manifesto, 500);
        
        newCandidate.votesReceived = 0;
        
        candidates[candidateCount] = newCandidate;
        candidateCount++;
        
        loadingAnimation("Registering candidate");
        printSuccess("Candidate registered successfully! Candidate ID: " + to_string(newCandidate.candidateID));
        return true;
    }
    
    // Display all candidates
    void displayAllCandidates(bool showVotes = true) {
        if (candidateCount == 0) {
            printInfo("No candidates registered.");
            return;
        }
        
        setColor(BRIGHT_CYAN);
        cout << "\n========================================================================================================\n";
        cout << "                                   ALL CANDIDATES\n";
        cout << "========================================================================================================\n";
        cout << left << setw(12) << "Candidate ID" << setw(25) << "Name" 
             << setw(20) << "Party" << setw(15) << "Symbol" 
             << setw(20) << "Constituency";
        if (showVotes) {
            cout << setw(10) << "Votes";
        }
        cout << endl;
        cout << "--------------------------------------------------------------------------------------------------------\n";
        setColor(WHITE_COLOR);
        
        for (int i = 0; i < candidateCount; i++) {
            cout << "  ";
            candidates[i].displayBrief(showVotes);
        }
        
        setColor(BRIGHT_CYAN);
        cout << "========================================================================================================\n";
        setColor(BRIGHT_YELLOW);
        cout << "\nTotal Candidates: " << candidateCount << endl;
        setColor(WHITE_COLOR);
    }
    
    // Search candidate by ID
    Candidate* searchCandidate(int candidateID) {
        for (int i = 0; i < candidateCount; i++) {
            if (candidates[i].candidateID == candidateID) {
                return &candidates[i];
            }
        }
        return NULL;
    }
    
    // Get candidates by constituency
    vector<Candidate*> getCandidatesByConstituency(const char* constituency) {
        vector<Candidate*> constituencyCandidates;
        for (int i = 0; i < candidateCount; i++) {
            if (strcmp(candidates[i].constituency, constituency) == 0) {
                constituencyCandidates.push_back(&candidates[i]);
            }
        }
        return constituencyCandidates;
    }
    
    // Add vote to candidate
    void addVote(int candidateID) {
        Candidate* candidate = searchCandidate(candidateID);
        if (candidate != NULL) {
            candidate->votesReceived++;
        }
    }
    
    // Get candidate count
    int getCandidateCount() { return candidateCount; }
    
    // Save candidates to file
    void saveToFile() {
        ofstream file("candidates.dat", ios::binary);
        if (!file) {
            printError("Error saving candidates data!");
            return;
        }
        
        for (int i = 0; i < candidateCount; i++) {
            file.write(reinterpret_cast<char*>(&candidates[i]), sizeof(Candidate));
        }
        
        file.close();
        printSuccess("Candidates data saved successfully!");
    }
    
    // Load candidates from file
    void loadFromFile() {
        ifstream file("candidates.dat", ios::binary);
        if (!file) {
            printInfo("No previous candidates data found.");
            addDefaultCandidates();
            return;
        }
        
        Candidate candidate;
        while (file.read(reinterpret_cast<char*>(&candidate), sizeof(Candidate))) {
            if (candidateCount < MAX_CANDIDATES) {
                candidates[candidateCount++] = candidate;
            }
        }
        
        file.close();
        printSuccess("Loaded " + to_string(candidateCount) + " candidates.");
    }
    
    // Add default candidates
    void addDefaultCandidates() {
        addDefaultCandidate(2001, "Ali Raza", "Pakistan Tehreek-e-Insaf", "Bat", "NA-125", 
                           "MSc Computer Science, 5 years public service", 
                           "Education reform, Job creation, Healthcare improvement", 45, "Male");
        addDefaultCandidate(2002, "Sadia Noor", "Pakistan Muslim League-N", "Lion", "NA-125", 
                           "PhD Economics, Former Minister", 
                           "Economic stability, Infrastructure development", 52, "Female");
        addDefaultCandidate(2003, "Faisal Qureshi", "Pakistan Peoples Party", "Arrow", "NA-250", 
                           "LLB, Human Rights Activist", 
                           "Social justice, Poverty alleviation", 48, "Male");
        addDefaultCandidate(2004, "Zainab Shah", "Muttahida Qaumi Movement", "Kite", "NA-250", 
                           "MBA, Business Leader", 
                           "Urban development, Youth employment", 41, "Female");
        addDefaultCandidate(2005, "Omar Farooq", "Jamiat Ulema-e-Islam", "Book", "NA-54", 
                           "Islamic Studies Scholar", 
                           "Islamic values, Educational reforms", 55, "Male");
        
        printSuccess("Added " + to_string(candidateCount) + " default candidates.");
    }
    
private:
    void addDefaultCandidate(int id, const char* name, const char* party, const char* symbol,
                            const char* constituency, const char* qual, const char* manifesto,
                            int age, const char* gender) {
        if (candidateCount >= MAX_CANDIDATES) return;
        
        Candidate c;
        c.candidateID = id;
        strcpy(c.name, name);
        strcpy(c.party, party);
        strcpy(c.symbol, symbol);
        strcpy(c.constituency, constituency);
        strcpy(c.qualifications, qual);
        strcpy(c.manifesto, manifesto);
        c.age = age;
        strcpy(c.gender, gender);
        c.votesReceived = 0;
        
        candidates[candidateCount++] = c;
    }
};

// ====================== VOTE MANAGEMENT ======================
class VoteManager {
private:
    Vote votes[MAX_VOTES];
    int voteCount;
    VoterManager* voterManager;
    CandidateManager* candidateManager;
    VotingTimer* votingTimer;
    
public:
    VoteManager(VoterManager* vm, CandidateManager* cm) {
        voteCount = 0;
        voterManager = vm;
        candidateManager = cm;
        votingTimer = new VotingTimer();
    }
    
    ~VoteManager() {
        delete votingTimer;
    }
    
    // Start voting session
    void startVotingSession() {
        clearScreen();
        printHeader("VOTING SESSION STARTED");
        
        setColor(BRIGHT_GREEN);
        cout << "\n============================================================\n";
        cout << "               VOTING SESSION INFORMATION\n";
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
        
        cout << "  Session Duration: " << VOTING_TIME_MINUTES << " minutes\n";
        cout << "  Total Voters:     " << voterManager->getVoterCount() << endl;
        cout << "  Total Candidates: " << candidateManager->getCandidateCount() << endl;
        
        setColor(BRIGHT_GREEN);
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
        
        votingTimer->start();
        printSuccess("Voting session started! Timer is now running.");
        sleep(2000);
    }
    
    // Cast vote with timer check
    bool castVote() {
        if (votingTimer->checkTime()) {
            return false;
        }
        
        clearScreen();
        printHeader("CAST YOUR VOTE");
        votingTimer->displayTimer();
        
        int voterID;
        cout << "\nEnter your Voter ID: ";
        cin >> voterID;
        
        // Check voter
        Voter* voter = voterManager->searchVoter(voterID);
        if (voter == NULL) {
            printError("Voter not found!");
            cout << "\nPress Enter to continue...";
            cin.ignore();
            cin.get();
            return false;
        }
        
        if (voter->hasVoted) {
            printError("You have already cast your vote!");
            cout << "\nPress Enter to continue...";
            cin.ignore();
            cin.get();
            return false;
        }
        
        // Check if voter is eligible (age >= 18)
        if (voter->age < 18) {
            printError("You are not eligible to vote (must be 18 or older)!");
            cout << "\nPress Enter to continue...";
            cin.ignore();
            cin.get();
            return false;
        }
        
        // Get candidates for voter's constituency
        vector<Candidate*> constituencyCandidates = 
            candidateManager->getCandidatesByConstituency(voter->constituency);
        
        if (constituencyCandidates.empty()) {
            printError("No candidates available in your constituency!");
            cout << "\nPress Enter to continue...";
            cin.ignore();
            cin.get();
            return false;
        }
        
        // Display candidates
        setColor(BRIGHT_CYAN);
        cout << "\n============================================================\n";
        cout << "      CANDIDATES IN YOUR CONSTITUENCY: " << voter->constituency << "\n";
        cout << "============================================================\n";
        cout << left << setw(12) << "Candidate ID" << setw(25) << "Name" 
             << setw(20) << "Party" << setw(15) << "Symbol" << endl;
        cout << "----------------------------------------------------------------------------\n";
        setColor(WHITE_COLOR);
        
        for (int i = 0; i < constituencyCandidates.size(); i++) {
            cout << left << setw(12) << constituencyCandidates[i]->candidateID
                 << setw(25) << constituencyCandidates[i]->name
                 << setw(20) << constituencyCandidates[i]->party
                 << setw(15) << constituencyCandidates[i]->symbol << endl;
        }
        
        setColor(BRIGHT_CYAN);
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
        
        // Get vote choice
        int candidateID;
        cout << "\nEnter Candidate ID to vote for: ";
        cin >> candidateID;
        
        // Validate candidate choice
        bool validCandidate = false;
        Candidate* chosenCandidate = NULL;
        
        for (auto& candidate : constituencyCandidates) {
            if (candidate->candidateID == candidateID) {
                validCandidate = true;
                chosenCandidate = candidate;
                break;
            }
        }
        
        if (!validCandidate) {
            printError("Invalid candidate choice!");
            cout << "\nPress Enter to continue...";
            cin.ignore();
            cin.get();
            return false;
        }
        
        // Confirm vote
        clearScreen();
        printHeader("CONFIRM YOUR VOTE");
        
        setColor(BRIGHT_YELLOW);
        cout << "\nYou are about to vote for:\n";
        cout << "------------------------------------------------------------\n";
        setColor(WHITE_COLOR);
        
        cout << "  Candidate:  " << chosenCandidate->name << endl;
        cout << "  Party:      " << chosenCandidate->party << endl;
        cout << "  Symbol:     " << chosenCandidate->symbol << endl;
        cout << "  Constituency: " << chosenCandidate->constituency << endl;
        
        setColor(BRIGHT_YELLOW);
        cout << "------------------------------------------------------------\n";
        setColor(WHITE_COLOR);
        
        char confirm;
        cout << "\nConfirm your vote? (Y/N): ";
        cin >> confirm;
        
        if (toupper(confirm) != 'Y') {
            printWarning("Vote cancelled!");
            cout << "\nPress Enter to continue...";
            cin.ignore();
            cin.get();
            return false;
        }
        
        // Record vote
        Vote newVote;
        newVote.voteID = 3000 + voteCount + 1;
        newVote.voterID = voterID;
        newVote.candidateID = candidateID;
        
        // Get current date and time
        time_t now = time(0);
        tm* ltm = localtime(&now);
        
        newVote.voteDate.day = ltm->tm_mday;
        newVote.voteDate.month = ltm->tm_mon + 1;
        newVote.voteDate.year = 1900 + ltm->tm_year;
        
        strftime(newVote.voteTime, 10, "%H:%M:%S", ltm);
        strcpy(newVote.constituency, voter->constituency);
        
        votes[voteCount] = newVote;
        voteCount++;
        
        // Update voter and candidate records
        voterManager->markVoted(voterID);
        candidateManager->addVote(candidateID);
        
        loadingAnimation("Processing your vote");
        
        setColor(BRIGHT_GREEN);
        cout << "\n============================================================\n";
        cout << "               VOTE SUCCESSFULLY CAST!\n";
        cout << "============================================================\n";
        cout << "Thank you for exercising your democratic right.\n";
        cout << "Your vote has been recorded.\n";
        cout << "Vote ID: " << newVote.voteID << endl;
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
        
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
        return true;
    }
    
    // Display all votes
    void displayAllVotes() {
        if (voteCount == 0) {
            printInfo("No votes have been cast yet.");
            return;
        }
        
        setColor(BRIGHT_YELLOW);
        cout << "\n========================================================================================================\n";
        cout << "                                    ALL VOTES\n";
        cout << "========================================================================================================\n";
        cout << left << setw(10) << "Vote ID" << setw(12) << "Voter ID" 
             << setw(15) << "Candidate ID" << setw(15) << "Date" 
             << setw(12) << "Time" << setw(20) << "Constituency" << endl;
        cout << "--------------------------------------------------------------------------------------------------------\n";
        setColor(WHITE_COLOR);
        
        for (int i = 0; i < voteCount; i++) {
            cout << left << setw(10) << votes[i].voteID
                 << setw(12) << votes[i].voterID
                 << setw(15) << votes[i].candidateID
                 << setw(15);
            
            cout << setfill('0') << setw(2) << votes[i].voteDate.day << "/" 
                 << setw(2) << votes[i].voteDate.month << "/" 
                 << setw(4) << votes[i].voteDate.year << setfill(' ');
            
            cout << setw(12) << votes[i].voteTime
                 << setw(20) << votes[i].constituency << endl;
        }
        
        setColor(BRIGHT_YELLOW);
        cout << "========================================================================================================\n";
        setColor(BRIGHT_YELLOW);
        cout << "\nTotal Votes Cast: " << voteCount << endl;
        setColor(WHITE_COLOR);
    }
    
    // Calculate and display results
    void displayResults() {
        if (voteCount == 0) {
            printInfo("No votes cast yet. Cannot display results.");
            return;
        }
        
        // Group candidates by constituency
        vector<string> constituencies;
        for (int i = 0; i < voteCount; i++) {
            string cons = votes[i].constituency;
            if (find(constituencies.begin(), constituencies.end(), cons) == constituencies.end()) {
                constituencies.push_back(cons);
            }
        }
        
        for (const auto& constituency : constituencies) {
            // Get candidates for this constituency
            vector<Candidate*> consCandidates = 
                candidateManager->getCandidatesByConstituency(constituency.c_str());
            
            if (consCandidates.empty()) continue;
            
            // Sort candidates by votes (descending)
            sort(consCandidates.begin(), consCandidates.end(),
                [](Candidate* a, Candidate* b) {
                    return a->votesReceived > b->votesReceived;
                });
            
            // Display constituency results
            setColor(BRIGHT_GREEN);
            cout << "\n========================================================================================================\n";
            cout << "                    ELECTION RESULTS: " << constituency << "\n";
            cout << "========================================================================================================\n";
            cout << left << setw(6) << "Rank" << setw(25) << "Candidate Name" 
                 << setw(20) << "Party" << setw(15) << "Symbol" 
                 << setw(10) << "Votes" << setw(12) << "Percentage" << endl;
            cout << "--------------------------------------------------------------------------------------------------------\n";
            setColor(WHITE_COLOR);
            
            // Calculate total votes in constituency
            int totalConsVotes = 0;
            for (auto& candidate : consCandidates) {
                totalConsVotes += candidate->votesReceived;
            }
            
            // Display each candidate
            for (int i = 0; i < consCandidates.size(); i++) {
                Candidate* c = consCandidates[i];
                float percentage = (totalConsVotes > 0) ? 
                    (static_cast<float>(c->votesReceived) / totalConsVotes * 100) : 0;
                
                cout << left << setw(6) << (i + 1)
                     << setw(25) << c->name
                     << setw(20) << c->party
                     << setw(15) << c->symbol;
                
                setColor(BRIGHT_YELLOW);
                cout << setw(10) << c->votesReceived;
                setColor(WHITE_COLOR);
                
                cout << setw(12) << fixed << setprecision(2) << percentage << "%" << endl;
            }
            
            // Declare winner
            if (!consCandidates.empty() && consCandidates[0]->votesReceived > 0) {
                cout << "--------------------------------------------------------------------------------------------------------\n";
                
                setColor(BRIGHT_CYAN);
                cout << "WINNER: " << consCandidates[0]->name << endl;
                cout << "Party: " << consCandidates[0]->party << endl;
                cout << "Votes: " << consCandidates[0]->votesReceived << endl;
                setColor(WHITE_COLOR);
            }
            
            setColor(BRIGHT_GREEN);
            cout << "========================================================================================================\n";
            setColor(WHITE_COLOR);
        }
        
        // Overall statistics
        displayVotingStatistics();
    }
    
    // Display voting statistics
    void displayVotingStatistics() {
        int totalVoters = voterManager->getVoterCount();
        float turnoutPercentage = (totalVoters > 0) ? 
            (static_cast<float>(voteCount) / totalVoters * 100) : 0;
        
        setColor(BRIGHT_MAGENTA);
        cout << "\n============================================================\n";
        cout << "               VOTING STATISTICS\n";
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
        
        cout << "  Total Registered Voters:  " << totalVoters << endl;
        cout << "  Total Votes Cast:         " << voteCount << endl;
        cout << "  Voter Turnout:            " << fixed << setprecision(2) << turnoutPercentage << "%" << endl;
        cout << "  Voting Time Remaining:    ";
        votingTimer->displayTimer();
        
        setColor(BRIGHT_MAGENTA);
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
    }
    
    // Get vote count
    int getVoteCount() { return voteCount; }
    
    // Save votes to file
    void saveToFile() {
        ofstream file("votes.dat", ios::binary);
        if (!file) {
            printError("Error saving votes data!");
            return;
        }
        
        for (int i = 0; i < voteCount; i++) {
            file.write(reinterpret_cast<char*>(&votes[i]), sizeof(Vote));
        }
        
        file.close();
        printSuccess("Votes data saved successfully!");
    }
    
    // Load votes from file
    void loadFromFile() {
        ifstream file("votes.dat", ios::binary);
        if (!file) {
            printInfo("No previous votes data found.");
            return;
        }
        
        Vote vote;
        while (file.read(reinterpret_cast<char*>(&vote), sizeof(Vote))) {
            if (voteCount < MAX_VOTES) {
                votes[voteCount++] = vote;
            }
        }
        
        file.close();
        printSuccess("Loaded " + to_string(voteCount) + " votes.");
    }
    
    // Check if voting session is active
    bool isVotingActive() {
        return !votingTimer->isTimeUp();
    }
    
    // Get remaining time
    int getRemainingTime() {
        return votingTimer->getRemainingTime();
    }
};

// ====================== VOTING SYSTEM ======================
class VotingSystem {
private:
    VoterManager voterManager;
    CandidateManager candidateManager;
    VoteManager* voteManager;
    bool votingActive;
    
public:
    VotingSystem() : voteManager(new VoteManager(&voterManager, &candidateManager)) {
        votingActive = false;
    }
    
    ~VotingSystem() {
        delete voteManager;
    }
    
    // Initialize system
    void initialize() {
        clearScreen();
        printHeader("ONLINE VOTING SYSTEM WITH TIMER");
        
        setColor(BRIGHT_YELLOW);
        cout << "\nDEVELOPED USING C++ WITH DATA STRUCTURES IMPLEMENTATION\n";
        cout << "   Secure, Transparent & Time-bound Democratic Voting Platform\n";
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
        
        loadingAnimation("Initializing system components", 1500);
        
        // Load existing data
        voterManager.loadFromFile();
        candidateManager.loadFromFile();
        voteManager->loadFromFile();
        
        printSuccess("System initialized successfully!");
        sleep(1500);
    }
    
    // Admin login
    bool adminLogin() {
        clearScreen();
        printHeader("ELECTION COMMISSION LOGIN");
        
        string username, password;
        int attempts = 3;
        
        while (attempts > 0) {
            setColor(CYAN);
            cout << "\n  Username: ";
            setColor(BRIGHT_WHITE);
            cin >> username;
            
            setColor(CYAN);
            cout << "  Password: ";
            setColor(BRIGHT_WHITE);
            cin >> password;
            setColor(WHITE_COLOR);
            
            if (username == ADMIN_USER && password == ADMIN_PASS) {
                loadingAnimation("Verifying credentials", 1000);
                printSuccess("Login successful! Welcome Election Commissioner.");
                sleep(1500);
                return true;
            } else {
                attempts--;
                if (attempts > 0) {
                    setColor(BRIGHT_RED);
                    cout << "\n  Invalid credentials. Attempts left: " << attempts << endl;
                    setColor(WHITE_COLOR);
                    sleep(1000);
                }
            }
        }
        
        printError("Maximum login attempts reached. Access denied!");
        sleep(2000);
        return false;
    }
    
    // Voter management menu
    void voterManagementMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("VOTER MANAGEMENT");
            
            setColor(BRIGHT_MAGENTA);
            cout << "\n  VOTER MENU\n";
            cout << "  =======================================================\n";
            setColor(WHITE_COLOR);
            
            cout << "  [1]  Register New Voter\n";
            cout << "  [2]  View All Voters\n";
            cout << "  [3]  Search Voter by ID\n";
            cout << "  [4]  Search Voter by CNIC\n";
            cout << "  [5]  Back to Main Menu\n";
            setColor(BRIGHT_MAGENTA);
            cout << "  =======================================================\n";
            cout << "  Select option [1-5]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE_COLOR);
            
            switch (choice) {
                case 1: 
                    voterManager.addVoter();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 2: 
                    voterManager.displayAllVoters();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 3: {
                    int voterID;
                    cout << "\nEnter Voter ID: ";
                    cin >> voterID;
                    Voter* voter = voterManager.searchVoter(voterID);
                    if (voter != NULL) {
                        voter->displayVoter();
                    } else {
                        printError("Voter not found!");
                    }
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 4: {
                    char cnic[15];
                    cin.ignore();
                    cout << "\nEnter CNIC: ";
                    cin.getline(cnic, 15);
                    Voter* voter = voterManager.searchVoterByCNIC(cnic);
                    if (voter != NULL) {
                        voter->displayVoter();
                    } else {
                        printError("Voter not found!");
                    }
                    cout << "\nPress Enter to continue...";
                    cin.get();
                    break;
                }
                case 5: 
                    break;
                default:
                    printError("Invalid choice!");
                    sleep(2000);
            }
            
        } while (choice != 5);
    }
    
    // Candidate management menu
    void candidateManagementMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("CANDIDATE MANAGEMENT");
            
            setColor(BRIGHT_CYAN);
            cout << "\n  CANDIDATE MENU\n";
            cout << "  =======================================================\n";
            setColor(WHITE_COLOR);
            
            cout << "  [1]  Register New Candidate\n";
            cout << "  [2]  View All Candidates\n";
            cout << "  [3]  Search Candidate by ID\n";
            cout << "  [4]  View Candidates by Constituency\n";
            cout << "  [5]  Back to Main Menu\n";
            setColor(BRIGHT_CYAN);
            cout << "  =======================================================\n";
            cout << "  Select option [1-5]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE_COLOR);
            
            switch (choice) {
                case 1: 
                    candidateManager.addCandidate();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 2: 
                    candidateManager.displayAllCandidates();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 3: {
                    int candidateID;
                    cout << "\nEnter Candidate ID: ";
                    cin >> candidateID;
                    Candidate* candidate = candidateManager.searchCandidate(candidateID);
                    if (candidate != NULL) {
                        candidate->displayCandidate();
                    } else {
                        printError("Candidate not found!");
                    }
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                }
                case 4: {
                    char constituency[50];
                    cin.ignore();
                    cout << "\nEnter Constituency: ";
                    cin.getline(constituency, 50);
                    vector<Candidate*> candidates = 
                        candidateManager.getCandidatesByConstituency(constituency);
                    
                    if (!candidates.empty()) {
                        setColor(BRIGHT_CYAN);
                        cout << "\nCandidates in " << constituency << ":\n";
                        cout << "------------------------------------------------------------\n";
                        setColor(WHITE_COLOR);
                        
                        for (auto& candidate : candidates) {
                            cout << "  ID: " << candidate->candidateID 
                                 << " | Name: " << candidate->name 
                                 << " | Party: " << candidate->party 
                                 << " | Symbol: " << candidate->symbol << endl;
                        }
                    } else {
                        printError("No candidates found in this constituency!");
                    }
                    cout << "\nPress Enter to continue...";
                    cin.get();
                    break;
                }
                case 5: 
                    break;
                default:
                    printError("Invalid choice!");
                    sleep(2000);
            }
            
        } while (choice != 5);
    }
    
    // Voting menu
    void votingMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("VOTING SESSION");
            
            // Display timer if voting is active
            if (votingActive) {
                cout << "\n";
            }
            
            setColor(BRIGHT_YELLOW);
            cout << "\n  VOTING MENU\n";
            cout << "  =======================================================\n";
            setColor(WHITE_COLOR);
            
            if (!votingActive) {
                cout << "  [1]  Start Voting Session\n";
            } else {
                cout << "  [1]  Cast Vote (Session Active)\n";
            }
            cout << "  [2]  View All Votes\n";
            cout << "  [3]  View Election Results\n";
            cout << "  [4]  View Voting Statistics\n";
            cout << "  [5]  End Voting Session\n";
            cout << "  [6]  Back to Main Menu\n";
            setColor(BRIGHT_YELLOW);
            cout << "  =======================================================\n";
            cout << "  Select option [1-6]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE_COLOR);
            
            switch (choice) {
                case 1: 
                    if (!votingActive) {
                        voteManager->startVotingSession();
                        votingActive = true;
                        cout << "\nPress Enter to continue...";
                        cin.ignore();
                        cin.get();
                    } else {
                        if (!voteManager->castVote()) {
                            if (!voteManager->isVotingActive()) {
                                votingActive = false;
                                printInfo("Voting session has ended due to time limit.");
                                sleep(2000);
                            }
                        }
                    }
                    break;
                case 2: 
                    voteManager->displayAllVotes();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 3: 
                    voteManager->displayResults();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 4: 
                    voteManager->displayVotingStatistics();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 5: 
                    if (votingActive) {
                        votingActive = false;
                        printSuccess("Voting session ended manually.");
                    } else {
                        printInfo("No active voting session.");
                    }
                    sleep(2000);
                    break;
                case 6: 
                    break;
                default:
                    printError("Invalid choice!");
                    sleep(2000);
            }
            
        } while (choice != 6);
    }
    
    // Reports menu
    void reportsMenu() {
        clearScreen();
        printHeader("ELECTION REPORTS");
        
        setColor(BRIGHT_GREEN);
        cout << "\n============================================================\n";
        cout << "               ELECTION STATISTICS\n";
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
        
        cout << "\n  Total Registered Voters:   ";
        setColor(BRIGHT_MAGENTA);
        cout << voterManager.getVoterCount() << endl;
        setColor(WHITE_COLOR);
        
        cout << "  Total Registered Candidates: ";
        setColor(BRIGHT_CYAN);
        cout << candidateManager.getCandidateCount() << endl;
        setColor(WHITE_COLOR);
        
        cout << "  Total Votes Cast:           ";
        setColor(BRIGHT_YELLOW);
        cout << voteManager->getVoteCount() << endl;
        setColor(WHITE_COLOR);
        
        // Calculate turnout percentage
        int totalVoters = voterManager.getVoterCount();
        int totalVotes = voteManager->getVoteCount();
        float turnout = (totalVoters > 0) ? (static_cast<float>(totalVotes) / totalVoters * 100) : 0;
        
        cout << "  Voter Turnout:              ";
        if (turnout >= 50) {
            setColor(BRIGHT_GREEN);
        } else if (turnout >= 30) {
            setColor(BRIGHT_YELLOW);
        } else {
            setColor(BRIGHT_RED);
        }
        cout << fixed << setprecision(2) << turnout << "%" << endl;
        setColor(WHITE_COLOR);
        
        cout << "  Voting Session Status:      ";
        if (votingActive) {
            setColor(BRIGHT_GREEN);
            cout << "ACTIVE (Time remaining: " << voteManager->getRemainingTime() << " seconds)" << endl;
        } else {
            setColor(BRIGHT_RED);
            cout << "INACTIVE" << endl;
        }
        setColor(WHITE_COLOR);
        
        setColor(BRIGHT_GREEN);
        cout << "\n============================================================\n";
        setColor(WHITE_COLOR);
        
        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();
    }
    
    // Main menu
    void mainMenu() {
        int choice;
        
        do {
            clearScreen();
            printHeader("ONLINE VOTING SYSTEM");
            
            // Display system status
            setColor(BRIGHT_YELLOW);
            cout << "\n  SYSTEM STATUS: ";
            if (votingActive) {
                setColor(BRIGHT_GREEN);
                cout << "VOTING ACTIVE ";
                setColor(BRIGHT_CYAN);
                cout << "TIME " << voteManager->getRemainingTime() << "s remaining";
            } else {
                setColor(BRIGHT_RED);
                cout << "VOTING INACTIVE";
            }
            setColor(WHITE_COLOR);
            cout << "\n\n";
            
            setColor(BRIGHT_CYAN);
            cout << "\n  MAIN MENU\n";
            cout << "  =======================================================\n";
            setColor(WHITE_COLOR);
            
            cout << "  [1]  Voter Management\n";
            cout << "  [2]  Candidate Management\n";
            cout << "  [3]  Voting Session\n";
            cout << "  [4]  Election Reports\n";
            cout << "  [5]  Save All Data\n";
            cout << "  [6]  Exit System\n";
            setColor(BRIGHT_CYAN);
            cout << "  =======================================================\n";
            cout << "  Select option [1-6]: ";
            setColor(BRIGHT_WHITE);
            cin >> choice;
            setColor(WHITE_COLOR);
            
            switch (choice) {
                case 1: 
                    voterManagementMenu();
                    break;
                case 2: 
                    candidateManagementMenu();
                    break;
                case 3: 
                    votingMenu();
                    break;
                case 4: 
                    reportsMenu();
                    break;
                case 5: 
                    saveAllData();
                    cout << "\nPress Enter to continue...";
                    cin.ignore();
                    cin.get();
                    break;
                case 6: 
                    break;
                default:
                    printError("Invalid choice!");
                    sleep(2000);
            }
            
        } while (choice != 6);
    }
    
    // Save all data
    void saveAllData() {
        clearScreen();
        printHeader("SAVE ELECTION DATA");
        
        loadingAnimation("Saving all election data", 1500);
        
        voterManager.saveToFile();
        candidateManager.saveToFile();
        voteManager->saveToFile();
        
        printSuccess("All election data saved successfully!");
    }
    
    // Run system
    void run() {
        initialize();
        
        if (!adminLogin()) {
            return;
        }
        
        mainMenu();
        
        // Ask to save before exit
        clearScreen();
        printHeader("EXIT VOTING SYSTEM");
        
        char save;
        setColor(BRIGHT_YELLOW);
        cout << "\n  Save election data before exiting? (y/n): ";
        setColor(BRIGHT_WHITE);
        cin >> save;
        setColor(WHITE_COLOR);
        
        if (save == 'y' || save == 'Y') {
            saveAllData();
        }
        
        clearScreen();
        setColor(BRIGHT_CYAN);
        cout << "\n============================================================\n";
        cout << "                   THANK YOU FOR USING\n";
        cout << "           ONLINE VOTING SYSTEM WITH TIMER\n";
        cout << "     Democracy thrives when citizens participate!\n";
        cout << "                        Goodbye!\n";
        cout << "============================================================\n";
        setColor(WHITE_COLOR);
        
        sleep(2000);
    }
};

// ====================== MAIN FUNCTION ======================
int main() {
    VotingSystem votingSystem;
    votingSystem.run();
    return 0;
}